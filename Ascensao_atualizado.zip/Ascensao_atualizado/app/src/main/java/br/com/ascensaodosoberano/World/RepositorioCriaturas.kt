
package br.com.ascensaodosoberano.world

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

object RepositorioCriaturas {

    private val banco =
        FirebaseFirestore.getInstance()

    // Registra uma criatura somente se ela ainda não existir.
    suspend fun registrarCriaturaGlobal(
        criatura: CriaturaGerada
    ): CriaturaGerada {

        val ranksValidos = setOf(
            "E", "D", "C", "B", "A", "S", "SS", "SSS"
        )

        val raridadesValidas = setOf(
            "COMUM", "INCOMUM", "RARO",
            "ÉPICO", "LENDÁRIO", "MÍTICO", "MUNDO"
        )

        require(criatura.id.isNotBlank())
        require(criatura.nome.isNotBlank())
        require(criatura.rank.uppercase() in ranksValidos)
        require(criatura.vidaMaxima > 0)
        require(criatura.ataque >= 0 && criatura.defesa >= 0)
        require(criatura.experienciaBase >= 0)
        require(criatura.ecosystemId.isNotBlank())
        require(criatura.raridade.uppercase() in raridadesValidas)

        val referencia = banco
            .collection("criaturas")
            .document(criatura.id)

        return banco.runTransaction { transacao ->

            val documento = transacao.get(referencia)

            if (documento.exists()) {
                documento.toObject(CriaturaGerada::class.java)
                    ?: throw IllegalStateException(
                        "Dados da criatura oficial inválidos."
                    )
            } else {
                transacao.set(referencia, criatura)
                criatura
            }

        }.await()
    }

    // Busca todas as criaturas oficiais de um ecossistema.
    suspend fun buscarPorEcossistema(
        ecosystemId: String
    ): List<CriaturaGerada> {

        val resultado = banco
            .collection("criaturas")
            .whereEqualTo("ecosystemId", ecosystemId)
            .get()
            .await()

        return resultado.toObjects(CriaturaGerada::class.java)
    }

    // Busca uma criatura já registrada globalmente.
    suspend fun buscarCriatura(
        id: String
    ): CriaturaGerada? {

        val documento = banco
            .collection("criaturas")
            .document(id)
            .get()
            .await()

        return documento.toObject(CriaturaGerada::class.java)
    }

    // Registra a descoberta no bestiário individual.
    suspend fun registrarDescoberta(
    uid: String,
    criatura: CriaturaGerada
) {
    require(uid.isNotBlank())
    require(criatura.id.isNotBlank())

    val referencia = banco
        .collection("jogadores")
        .document(uid)
        .collection("bestiario")
        .document(criatura.id)

    banco.runTransaction { transacao ->

        val documento = transacao.get(referencia)

        if (!documento.exists()) {
            transacao.set(
                referencia,
                mapOf(
                    "criaturaId" to criatura.id,
                    "nome" to criatura.nome,
                    "dataDescoberta" to System.currentTimeMillis()
                )
            )
        }
    }.await()
}
    // Busca as criaturas descobertas pelo jogador.
    suspend fun buscarBestiario(
        uid: String
    ): List<CriaturaGerada> {

        require(uid.isNotBlank())

        val descobertas = banco
            .collection("jogadores")
            .document(uid)
            .collection("bestiario")
            .get()
            .await()

        return descobertas.documents.mapNotNull { documento ->

            val criaturaId =
                documento.getString("criaturaId")
                    ?: documento.id

            buscarCriatura(criaturaId)
        }
    }
}