
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.companions.InventoryItem

object MonsterDropDatabase {

    private fun material(
        id: String,
        name: String,
        description: String,
        chance: Int,
        min: Int = 1,
        max: Int = 1
    ) = DropEntry(
        item = InventoryItem(
            id = id,
            name = name,
            description = description,
            type = "Material de criação"
        ),
        chance = chance,
        minQuantity = min,
        maxQuantity = max
    )

    val tables = listOf(

        MonsterDropTable(
            monsterId = "shadow_wolf",
            materials = listOf(
                material(
                    "wolf_pelt",
                    "Pele de Lobo",
                    "Pele resistente usada na criação de armaduras.",
                    75, 1, 2
                ),
                material(
                    "wolf_meat",
                    "Carne de Lobo",
                    "Carne que pode ser utilizada em receitas.",
                    80, 1, 3
                ),
                material(
                    "wolf_fang",
                    "Presa de Lobo",
                    "Presa afiada usada na fabricação de armas.",
                    35, 1, 2
                ),
                material(
                    "shadow_essence",
                    "Essência Sombria",
                    "Essência energética encontrada em lobos sombrios.",
                    8
                )
            )
        ),

        MonsterDropTable(
            monsterId = "abyss_crawler",
            materials = listOf(
                material(
                    "abyss_carapace",
                    "Carapaça Abissal",
                    "Fragmento resistente para armaduras.",
                    65, 1, 3
                ),
                material(
                    "abyss_claw",
                    "Garra Abissal",
                    "Garra que pode ser usada em armas.",
                    40, 1, 2
                ),
                material(
                    "abyss_core",
                    "Núcleo Abissal",
                    "Núcleo carregado de energia abissal.",
                    12
                )
            )
        ),

        MonsterDropTable(
            monsterId = "dimensional_predator",
            materials = listOf(
                material(
                    "dimensional_hide",
                    "Couro Dimensional",
                    "Material raro para equipamentos dimensionais.",
                    65, 1, 3
                ),
                material(
                    "dimensional_fang",
                    "Presa Dimensional",
                    "Presa capaz de conduzir energia dimensional.",
                    40, 1, 2
                ),
                material(
                    "dimensional_core",
                    "Núcleo Dimensional",
                    "Concentra uma poderosa energia dimensional.",
                    15
                )
            )
        ),

        MonsterDropTable(
            monsterId = "nhar_zul_boss",
            materials = listOf(
                material(
                    "nhar_zul_scale",
                    "Escama de Nhar-Zul",
                    "Escama extremamente resistente.",
                    70, 2, 5
                ),
                material(
                    "calamity_fragment",
                    "Fragmento da Calamidade",
                    "Fragmento de energia destrutiva.",
                    30, 1, 2
                ),
                material(
                    "sovereign_core",
                    "Núcleo do Soberano",
                    "Núcleo de poder extraordinário.",
                    10
                )
            )
        )
    )

    fun getTable(monsterId: String): MonsterDropTable? {
        return tables.find { it.monsterId == monsterId }
    }
}
