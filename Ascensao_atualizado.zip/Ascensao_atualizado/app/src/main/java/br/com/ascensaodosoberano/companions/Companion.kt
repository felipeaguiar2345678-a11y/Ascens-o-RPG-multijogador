
package br.com.ascensaodosoberano.companions

data class Companion(
    val id: String,
    val name: String,
    val species: String,
    val rank: String,
    val level: Int = 1,
    val xp: Int = 0,
    val maxHp: Int,
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val agility: Int,
    val magicPower: Int,
    val imageKey: String,
    val isActive: Boolean = false,
    val imagemIconeCaminho: String = "",
    val imagemDetalhadaCaminho: String = "",
    val imagemSpriteCaminho: String = ""
)