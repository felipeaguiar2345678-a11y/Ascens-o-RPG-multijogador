
package br.com.ascensaodosoberano.character

import br.com.ascensaodosoberano.powers.PowerStatus
import br.com.ascensaodosoberano.powers.PowerType
import br.com.ascensaodosoberano.powers.PowerOrigin
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class CharacterProfileRepository(
    private val db: FirebaseFirestore =
        FirebaseFirestore.getInstance()
) {

    suspend fun save(profile: CharacterProfile) {
        val ownerUid = FirebaseAuth.getInstance()
            .currentUser?.uid
            ?: throw IllegalStateException(
                "Usuário precisa estar autenticado."
            )

        val data = mapOf(
            "id" to profile.id,
            "powerProfile" to mapOf(
    "desires" to profile.powerProfile.desires.map { desire ->
        mapOf(
            "id" to desire.id,
            "name" to desire.name,
            "description" to desire.description,
            "desiredType" to desire.desiredType.name,
            "progress" to desire.progress,
            "createdAt" to desire.createdAt
        )
    },
    "powers" to profile.powerProfile.powers.map { power ->
        mapOf(
            "id" to power.id,
            "name" to power.name,
            "description" to power.description,
            "type" to power.type.name,
            "origin" to power.origin.name,
            "status" to power.status.name,
            "level" to power.level,
            "experience" to power.experience,
            "manaCost" to power.manaCost,
            "baseDamage" to power.baseDamage,
            "cooldown" to power.cooldown,
            "effects" to power.effects,
            "limitations" to power.limitations
        )
    },
    "observations" to profile.powerProfile.observations.map { observation ->
        mapOf(
            "action" to observation.action,
            "category" to observation.category,
            "intensity" to observation.intensity,
            "timestamp" to observation.timestamp,
            "difficulty" to observation.difficulty,
            "origin" to observation.origin?.name,
            "successful" to observation.successful,
            "tags" to observation.tags
        )
    }
),
            "ownerUid" to ownerUid,
            "name" to profile.name,
"hasSeenIntro" to profile.hasSeenIntro,

// Localização persistente no mundo
"currentWorldPointId" to profile.currentWorldPointId,
"respawnPointId" to profile.respawnPointId,

"level" to profile.level,
            "xp" to profile.xp,
            "attributePoints" to profile.attributePoints,

            "characterClass" to mapOf(
                "id" to profile.characterClass.id,
                "name" to profile.characterClass.name,
                "description" to profile.characterClass.description,
                "isCustom" to profile.characterClass.isCustom,
                "affinities" to profile.characterClass.affinities.mapKeys {
                    it.key.name
                }.mapValues {
                    it.value.name
                }
            ),

            "attributes" to mapOf(
                "strength" to profile.attributes.strength,
                "intelligence" to profile.attributes.intelligence,
                "agility" to profile.attributes.agility,
                "vitality" to profile.attributes.vitality,
                "spirit" to profile.attributes.spirit
            ),

            "appearance" to mapOf(
                "skinId" to profile.appearance.skinId,
                "faceId" to profile.appearance.faceId,
                "hairId" to profile.appearance.hairId,
                "hairColorId" to profile.appearance.hairColorId,
                "eyeId" to profile.appearance.eyeId,
                "outfitId" to profile.appearance.outfitId,
                "generatedImagePath" to profile.appearance.generatedImagePath,
                "generatedImageUrl" to profile.appearance.generatedImageUrl,
                "generationId" to profile.appearance.generationId,
                "visualVersion" to profile.appearance.visualVersion,
                "idleSpritePath" to profile.appearance.idleSpritePath,
                "walkingSpritesPath" to profile.appearance.walkingSpritesPath,
                "directionalSpritesPath" to profile.appearance.directionalSpritesPath
            )
        )

        db.collection("characters")
            .document(profile.id)
            .set(data)
            .await()
    }

    suspend fun getForCurrentUser(): CharacterProfile? {
        val uid = FirebaseAuth.getInstance()
            .currentUser?.uid
            ?: return null

        val result = db.collection("characters")
            .whereEqualTo("ownerUid", uid)
            .limit(1)
            .get()
            .await()

        val doc = result.documents.firstOrNull()
            ?: return null

        val classData =
            doc.get("characterClass") as? Map<*, *>
                ?: emptyMap<Any, Any>()

        val attributesData =
            doc.get("attributes") as? Map<*, *>
                ?: emptyMap<Any, Any>()

        val appearanceData =
            doc.get("appearance") as? Map<*, *>
                ?: emptyMap<Any, Any>()

        val powerProfileData =
    doc.get("powerProfile") as? Map<*, *>
        ?: emptyMap<Any, Any>()

        val affinitiesData =
            classData["affinities"] as? Map<*, *>
                ?: emptyMap<Any, Any>()

        val affinities = affinitiesData.mapNotNull { (key, value) ->
            val domain = runCatching {
                SkillDomain.valueOf(key.toString())
            }.getOrNull()

            val affinity = runCatching {
                Affinity.valueOf(value.toString())
            }.getOrNull()

            if (domain != null && affinity != null) {
                domain to affinity
            } else {
                null
            }
        }.toMap()

        val characterClass = CharacterClass(
            id = classData["id"]?.toString() ?: "desconhecida",
            name = classData["name"]?.toString() ?: "Aventureiro",
            description = classData["description"]?.toString() ?: "",
            isCustom = classData["isCustom"] as? Boolean ?: false,
            affinities = affinities
        )

        val attributes = CharacterAttributes(
            strength = (attributesData["strength"] as? Number)?.toInt() ?: 5,
            intelligence = (attributesData["intelligence"] as? Number)?.toInt() ?: 5,
            agility = (attributesData["agility"] as? Number)?.toInt() ?: 5,
            vitality = (attributesData["vitality"] as? Number)?.toInt() ?: 5,
            spirit = (attributesData["spirit"] as? Number)?.toInt() ?: 5
        )

        val appearance = CharacterAppearance(
            skinId = appearanceData["skinId"]?.toString() ?: "pele_01",
            faceId = appearanceData["faceId"]?.toString() ?: "rosto_01",
            hairId = appearanceData["hairId"]?.toString() ?: "cabelo_01",
            hairColorId = appearanceData["hairColorId"]?.toString() ?: "castanho",
            eyeId = appearanceData["eyeId"]?.toString() ?: "olhos_01",
            outfitId = appearanceData["outfitId"]?.toString() ?: "roupa_inicial_01",
            generatedImagePath = appearanceData["generatedImagePath"]?.toString() ?: "",
            generatedImageUrl = appearanceData["generatedImageUrl"]?.toString() ?: "",
            generationId = appearanceData["generationId"]?.toString() ?: "",
            visualVersion = (appearanceData["visualVersion"] as? Number)?.toInt() ?: 1,
            idleSpritePath = appearanceData["idleSpritePath"]?.toString() ?: "",
            walkingSpritesPath = appearanceData["walkingSpritesPath"]?.toString() ?: "",
            directionalSpritesPath = appearanceData["directionalSpritesPath"]?.toString() ?: ""
        )
val desires = (powerProfileData["desires"] as? List<*>)
    .orEmpty()
    .mapNotNull { item ->
        val map = item as? Map<*, *> ?: return@mapNotNull null

        val type = runCatching {
            br.com.ascensaodosoberano.powers.PowerType.valueOf(
                map["desiredType"].toString()
            )
        }.getOrNull() ?: return@mapNotNull null

        br.com.ascensaodosoberano.powers.PowerDesire(
            id = map["id"]?.toString() ?: return@mapNotNull null,
            name = map["name"]?.toString() ?: "",
            description = map["description"]?.toString() ?: "",
            desiredType = type,
            progress = (map["progress"] as? Number)?.toInt() ?: 0,
            createdAt = (map["createdAt"] as? Number)?.toLong()
                ?: System.currentTimeMillis()
        )
    }

val powers = (powerProfileData["powers"] as? List<*>)
    .orEmpty()
    .mapNotNull { item ->
        val map = item as? Map<*, *> ?: return@mapNotNull null

        val type = runCatching {
            br.com.ascensaodosoberano.powers.PowerType.valueOf(
                map["type"].toString()
            )
        }.getOrNull() ?: return@mapNotNull null

        val origin = runCatching {
            PowerOrigin.valueOf(map["origin"].toString())
        }.getOrNull() ?: return@mapNotNull null

        val status = runCatching {
            PowerStatus.valueOf(map["status"].toString())
        }.getOrDefault(PowerStatus.AWAKENED)

        br.com.ascensaodosoberano.powers.AwakenedPower(
            id = map["id"]?.toString() ?: return@mapNotNull null,
            name = map["name"]?.toString() ?: "",
            description = map["description"]?.toString() ?: "",
            type = type,
            origin = origin,
            status = status,
            level = (map["level"] as? Number)?.toInt() ?: 1,
            experience = (map["experience"] as? Number)?.toInt() ?: 0,
            manaCost = (map["manaCost"] as? Number)?.toInt() ?: 0,
            baseDamage = (map["baseDamage"] as? Number)?.toInt() ?: 0,
            cooldown = (map["cooldown"] as? Number)?.toInt() ?: 0,
            effects = (map["effects"] as? List<*>)?.map { it.toString() } ?: emptyList(),
            limitations = (map["limitations"] as? List<*>)?.map { it.toString() } ?: emptyList()
        )
    }

val observations = (powerProfileData["observations"] as? List<*>)
    .orEmpty()
    .mapNotNull { item ->
        val map = item as? Map<*, *> ?: return@mapNotNull null

        br.com.ascensaodosoberano.powers.PowerObservation(
            action = map["action"]?.toString() ?: "",
            category = map["category"]?.toString() ?: "",
            intensity = (map["intensity"] as? Number)?.toInt() ?: 0,
            timestamp = (map["timestamp"] as? Number)?.toLong()
                ?: System.currentTimeMillis(),
            difficulty = (map["difficulty"] as? Number)?.toInt() ?: 1,
            origin = map["origin"]?.toString()?.let {
                runCatching { PowerOrigin.valueOf(it) }.getOrNull()
            },
            successful = map["successful"] as? Boolean ?: true,
            tags = (map["tags"] as? List<*>)?.map { it.toString() } ?: emptyList()
        )
    }

val powerProfile = br.com.ascensaodosoberano.powers.CharacterPowerProfile(
    desires = desires,
    powers = powers,
    observations = observations
)
        return CharacterProfile(
            id = doc.id,
name = doc.getString("name") ?: "Aventureiro",
hasSeenIntro = doc.getBoolean("hasSeenIntro") ?: false,
powerProfile = powerProfile,

// Recupera a localização persistida
currentWorldPointId =
    doc.getString("currentWorldPointId") ?: "clareira_inicial",

respawnPointId =
    doc.getString("respawnPointId") ?: "aurelia",

level = (doc.getLong("level") ?: 1L).toInt(),
            xp = (doc.getLong("xp") ?: 0L).toInt(),
            characterClass = characterClass,
            attributes = attributes,
            attributePoints = (doc.getLong("attributePoints") ?: 0L).toInt(),
            appearance = appearance
        )
    }
}
