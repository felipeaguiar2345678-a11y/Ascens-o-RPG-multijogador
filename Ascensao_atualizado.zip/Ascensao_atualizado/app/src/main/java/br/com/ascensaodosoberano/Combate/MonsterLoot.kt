
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.companions.InventoryItem
import br.com.ascensaodosoberano.companions.Equipment
import br.com.ascensaodosoberano.companions.PetEgg
import br.com.ascensaodosoberano.companions.PetEggSystem
import br.com.ascensaodosoberano.world.CriaturaGerada

data class MonsterLoot(
    val egg: PetEgg? = null,
    val items: List<InventoryItem> = emptyList(),
    val equipment: List<Equipment> = emptyList()
)

object MonsterLootSystem {

    fun generate(
        criatura: CriaturaGerada
    ): MonsterLoot {

        val egg = PetEggSystem.rollEggDrop(
            monsterId = criatura.id,
            species = criatura.nome,
            rank = criatura.rank,
            imageKey = criatura.imagemId.ifBlank {
                criatura.imagemIconeCaminho
            }
        )

        val drops = MonsterDropSystem.roll(criatura)

        return MonsterLoot(
            egg = egg,
            items = drops.materials,
            equipment = drops.equipment
        )
    }
}
