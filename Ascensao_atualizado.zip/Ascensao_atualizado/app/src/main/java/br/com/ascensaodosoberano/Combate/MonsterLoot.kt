
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.companions.InventoryItem
import br.com.ascensaodosoberano.companions.PetEgg
import br.com.ascensaodosoberano.companions.PetEggSystem

data class MonsterLoot(
    val egg: PetEgg? = null,
    val items: List<InventoryItem> = emptyList()
)

object MonsterLootSystem {

    fun generate(
        monsterId: String,
        monsterName: String,
        rank: String,
        imageKey: String
    ): MonsterLoot {

        val egg = PetEggSystem.rollEggDrop(
            monsterId = monsterId,
            species = monsterName,
            rank = rank,
            imageKey = imageKey
        )

        return MonsterLoot(
            egg = egg
        )
    }
}
