
package br.com.ascensaodosoberano

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import br.com.ascensaodosoberano.character.CharacterProfile
import br.com.ascensaodosoberano.character.CharacterCreationScreen
import br.com.ascensaodosoberano.exploration.ExplorationSystem
import br.com.ascensaodosoberano.exploration.ExplorationEncounter
import br.com.ascensaodosoberano.combat.Combatant
import br.com.ascensaodosoberano.combat.CombatState
import br.com.ascensaodosoberano.combat.CombatPhase
import br.com.ascensaodosoberano.combat.CombatFactory
import br.com.ascensaodosoberano.combat.CombatSystem
import br.com.ascensaodosoberano.combat.CharacterCombatFactory
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        runCatching {
            FirebaseApp.initializeApp(this)
        }

        setContent {
            MaterialTheme {
                GameApp()
            }
        }
    }
}

data class Power(
    val name: String,
    val cost: String,
    val detail: String
)

@Composable
fun GameApp() {

    var page by remember { mutableStateOf(0) }

    var message by remember {
        mutableStateOf("Bem-vindo ao Ascensão do Soberano!")
    }

    var characterProfile by remember {
        mutableStateOf<CharacterProfile?>(null)
    }

    var invite by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    if (characterProfile == null) {
        CharacterCreationScreen(
            onCharacterCreated = {
                characterProfile = it
            }
        )
        return
    }

    val profile = characterProfile!!

    var hero by remember(profile) {
        mutableStateOf(
            CharacterCombatFactory.createHero(profile)
        )
    }

    var selectedRegion by remember {
        mutableStateOf(ExplorationSystem.regions.first())
    }

    var encounter by remember {
        mutableStateOf<ExplorationEncounter?>(null)
    }

    var combat by remember {
        mutableStateOf<CombatState?>(null)
    }

    val powers = remember {
        listOf(
            Power(
                "Ataque físico",
                "0 Mana",
                "Ataque básico usando força física."
            ),
            Power(
                "Habilidade especial",
                "20 Mana",
                "As habilidades especiais serão desenvolvidas."
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBarCompat("Ascensão do Soberano")
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    "Personagem",
                    "Combate",
                    "Multiplayer",
                    "Mundo"
                ).forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = page == index,
                        onClick = { page = index },
                        icon = {},
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            when (page) {

                // PERSONAGEM
                0 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            profile.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    item {
                        Text("Nível ${profile.level} • XP ${profile.xp}")
                    }

                    item {
                        Text("Classe: ${profile.characterClass.name}")
                    }

                    item {
                        Text(profile.characterClass.description)
                    }

                    item {
                        Text(
                            "ATRIBUTOS DE COMBATE",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    item {
                        Text("Vida: ${hero.hp}/${hero.maxHp}")
                    }

                    item {
                        Text("Mana: ${hero.mana}/${hero.maxMana}")
                    }

                    item {
                        Text("Ataque: ${hero.attack}")
                    }

                    item {
                        Text("Defesa: ${hero.defense}")
                    }

                    item {
                        Text("Rank: ${hero.rank}")
                    }
                }

                // COMBATE
                1 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "COMBATE",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    item {
                        Text(
                            "Explore o mundo para encontrar criaturas."
                        )
                    }

                    item {
                        combat?.let { state ->
                            Text("Inimigo: ${state.enemy.name}")
                            Text("Vida do inimigo: ${state.enemy.hp}/${state.enemy.maxHp}")
                            Text("Sua vida: ${state.hero.hp}/${state.hero.maxHp}")
                            Text("Turno: ${state.turn}")

                            Text(
                                "Fase: ${when (state.phase) {
                                    CombatPhase.PLAYER_TURN -> "Seu turno"
                                    CombatPhase.ENEMY_TURN -> "Turno do inimigo"
                                    CombatPhase.VICTORY -> "Vitória"
                                    CombatPhase.DEFEAT -> "Derrota"
                                    CombatPhase.ENEMY_ESCAPED -> "Inimigo fugiu"
                                }}"
                            )

                            if (state.phase == CombatPhase.PLAYER_TURN) {
                                Button(
                                    onClick = {
                                        combat = CombatSystem.playerAttack(state)
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("ATACAR")
                                }
                            }

                            if (combat?.phase == CombatPhase.ENEMY_TURN) {
                                Button(
                                    onClick = {
                                        val updated = CombatSystem.enemyAttack(state)
                                        combat = updated
                                        hero = updated.hero
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("AGUARDAR AÇÃO DO INIMIGO")
                                }
                            }

                            if (
                                state.phase == CombatPhase.VICTORY ||
                                state.phase == CombatPhase.DEFEAT ||
                                state.phase == CombatPhase.ENEMY_ESCAPED
                            ) {
                                Text("XP recebido: ${state.xpGained}")

                                Button(
                                    onClick = {
                                        hero = state.hero
                                        combat = null
                                        encounter = null
                                        message = "Combate encerrado."
                                    }
                                ) {
                                    Text("ENCERRAR COMBATE")
                                }
                            }

                            state.log.takeLast(8).forEach { line ->
                                Text(line)
                            }
                        } ?: Text("Nenhum combate em andamento.")
                    }
                }

                // MULTIPLAYER
                2 -> Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "MULTIPLAYER",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        "Crie campanhas e convide seus amigos."
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()
                                    val id = db.collection("campaigns")
                                        .document().id

                                    val inviteCode = (1..6)
                                        .map { ('A'..'Z').random() }
                                        .joinToString("")

                                    db.collection("campaigns")
                                        .document(id)
                                        .set(
                                            mapOf(
                                                "ownerUid" to user.uid,
                                                "inviteCode" to inviteCode,
                                                "name" to "Campanha de ${profile.name}",
                                                "visibility" to "private",
                                                "members" to listOf(user.uid),
                                                "createdAt" to System.currentTimeMillis()
                                            )
                                        ).await()

                                    invite = inviteCode
                                    message = "Campanha criada! Código: $inviteCode"

                                } catch (e: Exception) {
                                    message = "Erro online: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR CAMPANHA")
                    }

                    if (invite.isNotBlank()) {
                        Text("Código de convite: $invite")
                    }

                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("Código do amigo") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()

                                    val result = db.collection("campaigns")
                                        .whereEqualTo(
                                            "inviteCode",
                                            code.trim().uppercase()
                                        )
                                        .limit(1)
                                        .get()
                                        .await()

                                    val campaign = result.documents.firstOrNull()
                                        ?: error("Código não encontrado.")

                                    campaign.reference.update(
                                        "members",
                                        com.google.firebase.firestore.FieldValue
                                            .arrayUnion(user.uid)
                                    ).await()

                                    message = "Você entrou na campanha!"

                                } catch (e: Exception) {
                                    message = "Erro ao entrar: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ENTRAR NA CAMPANHA")
                    }
                }

                // MUNDO ABERTO
                else -> Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "MUNDO ABERTO",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text("Escolha uma região:")

                    ExplorationSystem.regions.forEach { region ->
                        Button(
                            onClick = {
                                selectedRegion = region
                                encounter = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${region.name} — Rank ${region.rank}")
                        }
                    }

                    Text("Região: ${selectedRegion.name}")

                    Button(
                        onClick = {
                            encounter = ExplorationSystem.explore(selectedRegion)
                            message = "Exploração concluída."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("EXPLORAR REGIÃO")
                    }

                    encounter?.let { result ->
                        Card {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(result.message)
                                Text("Evento: ${result.worldEvent?.title ?: "Nenhum"}")

                                Text(
                                    "Inimigo: ${result.enemyId ?: "Nenhum"}"
                                )

                                Text(
                                    "Chefe: ${if (result.isBoss) "Sim" else "Não"}"
                                )

                                if (result.enemyId != null) {
                                    Button(
                                        onClick = {
                                            combat = CombatFactory.createCombat(
                                                hero,
                                                result.enemyId
                                            )

                                            if (combat != null) {
                                                page = 1
                                                message = "Combate iniciado!"
                                            } else {
                                                message = "Não foi possível criar o combate."
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("ENFRENTAR CRIATURA")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            Text(
                message,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String) {
    TopAppBar(
        title = { Text(title) }
    )
}
