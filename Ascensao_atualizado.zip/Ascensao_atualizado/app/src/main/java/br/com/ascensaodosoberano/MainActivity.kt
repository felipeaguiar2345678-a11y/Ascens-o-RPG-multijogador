
package br.com.ascensaodosoberano

import br.com.ascensaodosoberano.powers.CharacterPowerProfile
import br.com.ascensaodosoberano.powers.PowerAwakeningEngine
import br.com.ascensaodosoberano.powers.PowerOrigin
import br.com.ascensaodosoberano.character.ProgressionSystem
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import br.com.ascensaodosoberano.character.CharacterProfile
import br.com.ascensaodosoberano.character.CharacterCreationScreen
import br.com.ascensaodosoberano.exploration.ExplorationSystem
import br.com.ascensaodosoberano.exploration.ExplorationEncounter
import br.com.ascensaodosoberano.combat.Combatant
import br.com.ascensaodosoberano.combat.CombatState
import br.com.ascensaodosoberano.combat.CombatPhase
import br.com.ascensaodosoberano.combat.CombatFactory
import br.com.ascensaodosoberano.combat.CombatSystem
import br.com.ascensaodosoberano.combat.CharacterCombatFactory
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        runCatching {
            FirebaseApp.initializeApp(this)
        }

        setContent {
    MaterialTheme {
        FluxoInicial()
         }
      }
    }
}

data class Power(
    val name: String,
    val cost: String,
    val detail: String
)

@Composable
fun GameApp() {

    var page by remember { mutableStateOf(0) }

    var message by remember {
        mutableStateOf("Bem-vindo ao Ascensão do Soberano!")
    }

    var characterProfile by remember {
        mutableStateOf<CharacterProfile?>(null)
    }
    var pendingLevelMessage by remember {
    mutableStateOf("")
}

    var invite by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    if (characterProfile == null) {
        CharacterCreationScreen(
            onCharacterCreated = {
                characterProfile = it
            }
        )
        return
    }

    val profile = characterProfile!!
    val nextLevelXp = ProgressionSystem.xpForNextLevel(profile.level)

val xpProgress = (
    profile.xp.toFloat() / nextLevelXp.toFloat()
).coerceIn(0f, 1f)

    var hero by remember {
        mutableStateOf(
            CharacterCombatFactory.createHero(profile)
        )
    }
    var powerProfile by remember {
    mutableStateOf(CharacterPowerProfile())
}

fun observePowerAction(
    action: String,
    category: String,
    intensity: Int,
    difficulty: Int = 1,
    origin: PowerOrigin? = null,
    successful: Boolean = true,
    tags: List<String> = emptyList()
) {
    powerProfile = PowerAwakeningEngine.observe(
        profile = powerProfile,
        action = action,
        category = category,
        intensity = intensity,
        difficulty = difficulty,
        origin = origin,
        successful = successful,
        tags = tags
    )

    val newDesires = PowerAwakeningEngine.evaluate(powerProfile)

    if (newDesires.isNotEmpty()) {
        powerProfile = powerProfile.copy(
            desires = powerProfile.desires + newDesires
        )
    }
}
    fun allocateAttribute(attribute: String) {
    val updatedProfile =
        ProgressionSystem.spendAttributePoint(profile, attribute)

    if (updatedProfile == profile) return

    val recalculatedHero =
        CharacterCombatFactory.createHero(updatedProfile)

    hero = recalculatedHero.copy(
        hp = hero.hp.coerceAtMost(recalculatedHero.maxHp),
        mana = hero.mana.coerceAtMost(recalculatedHero.maxMana)
    )

    characterProfile = updatedProfile
}

    var selectedRegion by remember {
        mutableStateOf(ExplorationSystem.regions.first())
    }

    var encounter by remember {
        mutableStateOf<ExplorationEncounter?>(null)
    }

    var combat by remember {
        mutableStateOf<CombatState?>(null)
    }

    val powers = remember {
        listOf(
            Power(
                "Ataque físico",
                "0 Mana",
                "Ataque básico usando força física."
            ),
            Power(
                "Habilidade especial",
                "20 Mana",
                "As habilidades especiais serão desenvolvidas."
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBarCompat("Ascensão do Soberano")
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    "Personagem",
                    "Combate",
                    "Multiplayer",
                    "Mundo"
                ).forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = page == index,
                        onClick = { page = index },
                        icon = {},
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            when (page) {


                // PERSONAGEM
                0 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            profile.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    item {
                        Text("Nível ${profile.level} • XP ${profile.xp}")
                    }

                    item {
                        LinearProgressIndicator(
                            progress = { xpProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Text(
                            "${(xpProgress * 100).toInt()}% de progresso para o próximo nível"
                        )
                    }

                    item {
                        Text(
                            "Próximo nível: ${nextLevelXp - profile.xp} XP restantes"
                        )
                    }

                    item {
                        Text("Classe: ${profile.characterClass.name}")
                        Text(profile.characterClass.description)
                    }

                    // ATRIBUTOS DE COMBATE
                    item {
                        Text(
                            "ATRIBUTOS DE COMBATE",
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text("Vida: ${hero.hp}/${hero.maxHp}")
                        Text("Mana: ${hero.mana}/${hero.maxMana}")
                        Text("Ataque: ${hero.attack}")
                        Text("Poder mágico: ${hero.magicPower}")
                        Text("Defesa: ${hero.defense}")
                        Text("Agilidade: ${hero.agility}")
                        Text("Rank: ${hero.rank}")
                    }

                    // DISTRIBUIÇÃO DE PONTOS
                    item {
                        Text(
                            "ATRIBUTOS DO PERSONAGEM",
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text(
                            "Pontos disponíveis: ${profile.attributePoints}"
                        )
                    }

                    item {
                        Text("Força: ${profile.attributes.strength}")

                        Button(
                            onClick = {
                                allocateAttribute("forca")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar força")
                        }
                    }

                    item {
                        Text("Inteligência: ${profile.attributes.intelligence}")

                        Button(
                            onClick = {
                                allocateAttribute("inteligencia")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar inteligência")
                        }
                    }

                    item {
                        Text("Agilidade: ${profile.attributes.agility}")

                        Button(
                            onClick = {
                                allocateAttribute("agilidade")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar agilidade")
                        }
                    }

                    item {
                        Text("Vitalidade: ${profile.attributes.vitality}")

                        Button(
                            onClick = {
                                allocateAttribute("vitalidade")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar vitalidade")
                        }
                    }

                    item {
                        Text("Espírito: ${profile.attributes.spirit}")

                        Button(
                            onClick = {
                                allocateAttribute("espirito")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar espírito")
                        }
                    }
                }

                // COMBATE

                1 -> LazyColumn(
                    verticalArrangement = 
                    Arrangement.spacedBy(10.dp)
                ) {                    
                    item {
                        Text(
                            "COMBATE",
                            style = MaterialTheme.typography.titleLarge
                        )

                        Text("Explore o mundo para encontrar criaturas.")
                    }

                    item {
                        combat?.let { state ->

                            Text("Inimigo: ${state.enemy.name}")
                            Text("Vida do inimigo: ${state.enemy.hp}/${state.enemy.maxHp}")
                            Text("Sua vida: ${state.hero.hp}/${state.hero.maxHp}")
                            Text("Turno: ${state.turn}")

                            Text(
                                "Fase: ${
                                    when (state.phase) {
                                        CombatPhase.PLAYER_TURN -> "Seu turno"
                                        CombatPhase.ENEMY_TURN -> "Turno do inimigo"
                                        CombatPhase.VICTORY -> "Vitória"
                                        CombatPhase.DEFEAT -> "Derrota"
                                        CombatPhase.ENEMY_ESCAPED -> "Inimigo fugiu"
                                    }
                                }"
                            )

                            // ATAQUE DO JOGADOR
                            if (state.phase == CombatPhase.PLAYER_TURN) {
                                Button(
                                    onClick = {
                                        val updatedCombat =
                                            CombatSystem.playerAttack(state)

                                        observePowerAction(
                                            action = "Realizou um ataque físico",
                                            category = "fisico",
                                            intensity = 10
                                        )

                                        combat = updatedCombat
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("ATACAR")
                                }
                                Button(
    onClick = {
        val updatedCombat =
            CombatSystem.playerDefend(state)

        observePowerAction(
            action = "Realizou uma defesa em combate",
            category = "defesa",
            intensity = 10
        )

        combat = updatedCombat
        hero = updatedCombat.hero
    },
    modifier = Modifier.fillMaxWidth()
) {
    Text("DEFENDER")
}
                            }

                            // TURNO DO INIMIGO
                            if (state.phase == CombatPhase.ENEMY_TURN) {
                                Button(
                                    onClick = {
                                        val updated =
                                            CombatSystem.enemyAttack(state)

                                        combat = updated
                                        hero = updated.hero
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("AGUARDAR AÇÃO DO INIMIGO")
                                }
                            }

                            // RESULTADO DO COMBATE
                            if (
                                state.phase == CombatPhase.VICTORY ||
                                state.phase == CombatPhase.DEFEAT ||
                                state.phase == CombatPhase.ENEMY_ESCAPED
                            ) {
                                Text("XP recebido: ${state.xpGained}")

                                Button(
                                    onClick = {
                                        if (state.phase == CombatPhase.VICTORY) {

                                            val progression =
                                                ProgressionSystem.gainXp(
                                                    profile,
                                                    state.xpGained
                                                )

                                            characterProfile =
                                                progression.profile

                                            if (progression.levelsGained > 0) {
                                                val upgradedHero =
                                                    CharacterCombatFactory.createHero(
                                                        progression.profile
                                                    )

                                                hero = upgradedHero.copy(
                                                    hp = state.hero.hp.coerceAtMost(
                                                        upgradedHero.maxHp
                                                    ),
                                                    mana = state.hero.mana.coerceAtMost(
                                                        upgradedHero.maxMana
                                                    )
                                                )

                                                pendingLevelMessage =
                                                    "Você subiu ${progression.levelsGained} nível(is)! Novo nível: ${progression.profile.level}"

                                            } else {
                                                hero = state.hero
                                                pendingLevelMessage =
                                                    "XP recebido: ${state.xpGained}"
                                            }

                                        } else {
                                            hero = state.hero
                                            pendingLevelMessage = ""
                                        }

                                        combat = null
                                        encounter = null
                                        message = pendingLevelMessage
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("ENCERRAR COMBATE")
                                }
                            }

                            // HISTÓRICO DO COMBATE
                            Text("HISTÓRICO")

                            state.log.takeLast(8).forEach { line ->
                                Text(line)
                            }

                        } ?: Text("Nenhum combate em andamento.")
                    }
                }

                // MULTIPLAYER

                2 -> Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "MULTIPLAYER",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        "Crie campanhas e convide seus amigos."
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()
                                    val id = db.collection("campaigns")
                                        .document().id

                                    val inviteCode = (1..6)
                                        .map { ('A'..'Z').random() }
                                        .joinToString("")

                                    db.collection("campaigns")
                                        .document(id)
                                        .set(
                                            mapOf(
                                                "ownerUid" to user.uid,
                                                "inviteCode" to inviteCode,
                                                "name" to "Campanha de ${profile.name}",
                                                "visibility" to "private",
                                                "members" to listOf(user.uid),
                                                "createdAt" to System.currentTimeMillis()
                                            )
                                        ).await()

                                    invite = inviteCode
                                    message = "Campanha criada! Código: $inviteCode"

                                } catch (e: Exception) {
                                    message = "Erro online: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR CAMPANHA")
                    }

                    if (invite.isNotBlank()) {
                        Text("Código de convite: $invite")
                    }

                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("Código do amigo") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()

                                    val result = db.collection("campaigns")
                                        .whereEqualTo(
                                            "inviteCode",
                                            code.trim().uppercase()
                                        )
                                        .limit(1)
                                        .get()
                                        .await()

                                    val campaign = result.documents.firstOrNull()
                                        ?: error("Código não encontrado.")

                                    campaign.reference.update(
                                        "members",
                                        com.google.firebase.firestore.FieldValue
                                            .arrayUnion(user.uid)
                                    ).await()

                                    message = "Você entrou na campanha!"

                                } catch (e: Exception) {
                                    message = "Erro ao entrar: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ENTRAR NA CAMPANHA")
                    }
                }

                // MUNDO ABERTO
                else -> Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "MUNDO ABERTO",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text("Escolha uma região:")

                    ExplorationSystem.regions.forEach { region ->
                        Button(
                            onClick = {
                                selectedRegion = region
                                encounter = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${region.name} — Rank ${region.rank}")
                        }
                    }

                    Text("Região: ${selectedRegion.name}")

                    Button(
                        onClick = {
                            encounter = ExplorationSystem.explore(selectedRegion)
                            message = "Exploração concluída."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("EXPLORAR REGIÃO")
                    }

                    encounter?.let { result ->
                        Card {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(result.message)
                                Text("Evento: ${result.worldEvent?.title ?: "Nenhum"}")

                                Text(
                                    "Inimigo: ${result.enemyId ?: "Nenhum"}"
                                )

                                Text(
                                    "Chefe: ${if (result.isBoss) "Sim" else "Não"}"
                                )

                                if (result.enemyId != null) {
                                    Button(
                                        onClick = {
                                            combat = CombatFactory.createCombat(
                                                hero,
                                                result.enemyId
                                            )

                                            if (combat != null) {
                                                page = 1
                                                message = "Combate iniciado!"
                                            } else {
                                                message = "Não foi possível criar o combate."
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("ENFRENTAR CRIATURA")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            Text(
                message,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String) {
    TopAppBar(
        title = { Text(title) }
    )
}
