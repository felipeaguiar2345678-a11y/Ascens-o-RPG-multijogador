
package br.com.ascensaodosoberano

import androidx.compose.ui.text.input.PasswordVisualTransformation
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import br.com.ascensaodosoberano.world.CriaturaGerada
import br.com.ascensaodosoberano.world.RepositorioCriaturas
import br.com.ascensaodosoberano.world.TelaMapaMundi
import br.com.ascensaodosoberano.world.WorldTravelPlan

import br.com.ascensaodosoberano.exploration.TelaMundo
import br.com.ascensaodosoberano.exploration.ExplorationSystem
import br.com.ascensaodosoberano.exploration.ExplorationEncounter
import br.com.ascensaodosoberano.exploration.EstadoCenaMundo
import br.com.ascensaodosoberano.exploration.ModoCenaMundo
import br.com.ascensaodosoberano.exploration.TransicaoMundo
import br.com.ascensaodosoberano.exploration.MovementDirection

import br.com.ascensaodosoberano.powers.PowerAwakeningEngine
import br.com.ascensaodosoberano.powers.PowerOrigin

import br.com.ascensaodosoberano.companions.PlayerInventory
import br.com.ascensaodosoberano.companions.InventorySystem
import br.com.ascensaodosoberano.companions.CompanionHatchingSystem
import br.com.ascensaodosoberano.companions.CompanionProgressionSystem

import br.com.ascensaodosoberano.character.CharacterProfile
import br.com.ascensaodosoberano.character.CharacterCreationScreen
import br.com.ascensaodosoberano.character.CharacterProfileRepository
import br.com.ascensaodosoberano.character.ProgressionSystem

import br.com.ascensaodosoberano.combat.CombatState
import br.com.ascensaodosoberano.combat.CombatPhase
import br.com.ascensaodosoberano.combat.CombatFactory
import br.com.ascensaodosoberano.combat.CombatSystem
import br.com.ascensaodosoberano.combat.CharacterCombatFactory
import br.com.ascensaodosoberano.combat.TelaCombate
import br.com.ascensaodosoberano.combat.MonsterLootSystem

import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        runCatching {
            FirebaseApp.initializeApp(this)
        }

        setContent {
            MaterialTheme {
                FluxoInicial()
            }
        }
    }
}

data class Power(
    val name: String,
    val cost: String,
    val detail: String
)

@Composable
fun GameApp() {

    val scope = rememberCoroutineScope()

    // Impede que gravações diferentes sobrescrevam umas às outras.
    val saveMutex = remember {
        Mutex()
    }

    var page by remember {
        mutableStateOf(0)
    }

    var showWorldMap by remember {
        mutableStateOf(false)
    }

    var pendingTravelPlan by remember {
        mutableStateOf<WorldTravelPlan?>(null)
    }

    var message by remember {
        mutableStateOf("Bem-vindo ao Ascensão do Soberano!")
    }

    var characterProfile by remember {
        mutableStateOf<CharacterProfile?>(null)
    }

    var loadingCharacter by remember {
        mutableStateOf(true)
    }

    var creationError by remember {
        mutableStateOf("")
    }

    var showIntro by remember {
        mutableStateOf(false)
    }

    var pendingLevelMessage by remember {
        mutableStateOf("")
    }

    var invite by remember {
        mutableStateOf("")
    }

    var code by remember {
        mutableStateOf("")
    }

    var bestiario by remember {
        mutableStateOf<List<CriaturaGerada>>(emptyList())
    }

    var carregandoBestiario by remember {
        mutableStateOf(false)
    }
    var contaVisitante by remember {
    mutableStateOf(
        FirebaseAuth.getInstance().currentUser?.isAnonymous == true
    )
}

var mostrarVinculacao by remember {
    mutableStateOf(false)
}

var emailVinculacao by remember {
    mutableStateOf("")
}

var senhaVinculacao by remember {
    mutableStateOf("")
}

var vinculandoConta by remember {
    mutableStateOf(false)
}

    LaunchedEffect(Unit) {
        try {
            val auth = FirebaseAuth.getInstance()

            if (auth.currentUser == null) {
                auth.signInAnonymously().await()
            }

            characterProfile =
    CharacterProfileRepository().getForCurrentUser()

contaVisitante =
    auth.currentUser?.isAnonymous == true

        } catch (e: Exception) {
            message =
                "Erro ao carregar personagem: ${e.localizedMessage}"
        } finally {
            loadingCharacter = false
        }
    }

    LaunchedEffect(page) {
        if (page == 3) {
            carregandoBestiario = true

            try {
                val uid = FirebaseAuth.getInstance()
                    .currentUser?.uid

                if (uid != null) {
                    bestiario =
                        RepositorioCriaturas.buscarBestiario(uid)
                }

            } catch (e: Exception) {
                message =
                    "Erro ao carregar bestiário: ${e.localizedMessage}"
            } finally {
                carregandoBestiario = false
            }
        }
    }

    if (loadingCharacter) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    if (characterProfile == null) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            if (creationError.isNotBlank()) {
                Text(
                    text = creationError,
                    color = MaterialTheme.colorScheme.error
                )
            }

            CharacterCreationScreen(
                onCharacterCreated = { createdProfile ->

                    scope.launch {
                        try {
                            val auth = FirebaseAuth.getInstance()

                            val user = auth.currentUser
                                ?: auth.signInAnonymously().await().user

                            if (user == null) {
                                error("Não foi possível autenticar o jogador.")
                            }

                            saveMutex.withLock {
                                CharacterProfileRepository().save(
                                    createdProfile
                                )
                            }

                            characterProfile = createdProfile
                            creationError = ""
                            message = "Personagem salvo na nuvem!"

                        } catch (e: Exception) {
                            creationError =
                                "Não foi possível salvar o personagem: ${e.localizedMessage}"
                        }
                    }
                }
            )
        }

        return
    }

    val profile = characterProfile!!

    LaunchedEffect(profile.id, profile.hasSeenIntro) {
        if (!profile.hasSeenIntro) {
            showIntro = true
        }
    }

    val nextLevelXp =
        ProgressionSystem.xpForNextLevel(profile.level)

    val xpProgress = (
        profile.xp.toFloat() / nextLevelXp.toFloat()
    ).coerceIn(0f, 1f)

    var hero by remember(profile.id) {
        mutableStateOf(
            CharacterCombatFactory.createHero(profile)
        )
    }

    var powerProfile by remember(profile.id) {
        mutableStateOf(profile.powerProfile)
    }

    var playerInventory by remember(profile.id) {
        mutableStateOf(profile.inventory)
    }

    // Controle para impedir duas eclosões simultâneas.
    var eclodindoOvoId by remember(profile.id) {
        mutableStateOf<String?>(null)
    }

    fun salvarPerfil(
        updatedProfile: CharacterProfile,
        erro: String
    ) {
        characterProfile = updatedProfile

        scope.launch {
            try {
                saveMutex.withLock {
                    CharacterProfileRepository().save(updatedProfile)
                }
            } catch (e: Exception) {
                message = "$erro: ${e.localizedMessage}"
            }
        }
    }

    fun atualizarInventario(
        updatedInventory: PlayerInventory
    ) {
        playerInventory = updatedInventory

        val updatedProfile = (
            characterProfile ?: profile
        ).copy(
            inventory = updatedInventory
        )

        salvarPerfil(
            updatedProfile,
            "Erro ao salvar inventário"
        )
    }

    fun allocateAttribute(attribute: String) {

        val currentProfile =
            characterProfile ?: profile

        val updatedProfile =
            ProgressionSystem.spendAttributePoint(
                currentProfile,
                attribute
            )

        if (updatedProfile == currentProfile) {
            return
        }

        val profileWithInventory =
            updatedProfile.copy(
                inventory = playerInventory
            )

        salvarPerfil(
            profileWithInventory,
            "Erro ao salvar atributos"
        )

        val updatedHero =
            CharacterCombatFactory.createHero(
                profileWithInventory
            )

        hero = updatedHero.copy(
            hp = hero.hp.coerceAtMost(updatedHero.maxHp),
            mana = hero.mana.coerceAtMost(updatedHero.maxMana)
        )
    }

    fun observePowerAction(
        action: String,
        category: String,
        intensity: Int,
        difficulty: Int = 1,
        origin: PowerOrigin? = null,
        successful: Boolean = true,
        tags: List<String> = emptyList()
    ) {

        powerProfile = PowerAwakeningEngine.observe(
            profile = powerProfile,
            action = action,
            category = category,
            intensity = intensity,
            difficulty = difficulty,
            origin = origin,
            successful = successful,
            tags = tags
        )

        val newDesires =
            PowerAwakeningEngine.evaluate(powerProfile)

        if (newDesires.isNotEmpty()) {
            powerProfile = powerProfile.copy(
                desires = powerProfile.desires + newDesires
            )
        }

        val updatedProfile = (
            characterProfile ?: profile
        ).copy(
            powerProfile = powerProfile,
            inventory = playerInventory
        )

        salvarPerfil(
            updatedProfile,
            "Erro ao salvar evolução dos poderes"
        )
    }

    var selectedRegion by remember {
        mutableStateOf(ExplorationSystem.regions.first())
    }

    var estadoMundo by remember {
        mutableStateOf(EstadoCenaMundo())
    }

    var direcaoMovimento by remember {
        mutableStateOf(MovementDirection())
    }

    var encounter by remember {
        mutableStateOf<ExplorationEncounter?>(null)
    }

    var combat by remember {
        mutableStateOf<CombatState?>(null)
    }

    var combateFinalizado by remember(profile.id) {
        mutableStateOf(false)
    }

    fun finalizarCombate(state: CombatState) {

        if (combateFinalizado) return

        combateFinalizado = true

        if (state.phase == CombatPhase.VICTORY) {

            val currentProfile =
                characterProfile ?: profile

            val criaturaDerrotada =
                encounter?.criatura

            val loot =
                criaturaDerrotada?.let { criatura ->
                    MonsterLootSystem.generate(criatura)
                }

            var inventarioAtualizado =
                playerInventory

            loot?.items?.forEach { item ->
                inventarioAtualizado =
                    InventorySystem.addItem(
                        inventarioAtualizado,
                        item
                    )
            }

            loot?.equipment?.forEach { equipamento ->
                inventarioAtualizado =
                    InventorySystem.addEquipment(
                        inventarioAtualizado,
                        equipamento
                    )
            }

            loot?.egg?.let { ovo ->
                inventarioAtualizado =
                    InventorySystem.addEgg(
                        inventarioAtualizado,
                        ovo
                    )
            }

            // XP do companheiro ativo: 50% do XP do jogador.
            var mensagemCompanheiro = ""

            val companheiroAtivo =
                InventorySystem.obterCompanheiroAtivo(
                    inventarioAtualizado
                )

            if (companheiroAtivo != null) {

                val resultadoCompanheiro =
                    CompanionProgressionSystem.gainXp(
                        companion = companheiroAtivo,
                        playerXp = state.xpGained
                    )

                val companheiroAtualizado =
                    resultadoCompanheiro.companion

                inventarioAtualizado =
                    inventarioAtualizado.copy(
                        companions = inventarioAtualizado.companions.map {
                            companheiro ->
                            if (companheiro.id == companheiroAtivo.id) {
                                companheiroAtualizado
                            } else {
                                companheiro
                            }
                        }
                    )

                if (resultadoCompanheiro.xpReceived > 0) {
                    mensagemCompanheiro =
                        "\n${companheiroAtualizado.name} recebeu ${resultadoCompanheiro.xpReceived} XP."
                }

                if (resultadoCompanheiro.levelsGained > 0) {
                    mensagemCompanheiro +=
                        "\n${companheiroAtualizado.name} subiu ${resultadoCompanheiro.levelsGained} nível(is)! Nível atual: ${companheiroAtualizado.level}. Estágio: ${companheiroAtualizado.stage}."
                }
            }

            playerInventory =
                inventarioAtualizado

            // Progressão normal do jogador permanece inalterada.
            val progression =
                ProgressionSystem.gainXp(
                    currentProfile,
                    state.xpGained
                )

            val progressedProfile =
                progression.profile.copy(
                    inventory = inventarioAtualizado
                )

            salvarPerfil(
                progressedProfile,
                "Erro ao salvar progresso"
            )

            if (progression.levelsGained > 0) {

                val upgradedHero =
                    CharacterCombatFactory.createHero(
                        progressedProfile
                    )

                hero = upgradedHero.copy(
                    hp = state.hero.hp.coerceAtMost(
                        upgradedHero.maxHp
                    ),
                    mana = state.hero.mana.coerceAtMost(
                        upgradedHero.maxMana
                    )
                )

                pendingLevelMessage =
                    "Você subiu ${progression.levelsGained} nível(is)! Novo nível: ${progressedProfile.level}"

            } else {

                hero = state.hero

                pendingLevelMessage =
                    "XP recebido: ${state.xpGained}"
            }

            pendingLevelMessage += mensagemCompanheiro

            if (loot != null) {

                val nomesRecompensas =
                    buildList {

                        addAll(
                            loot.items.map { it.name }
                        )

                        addAll(
                            loot.equipment.map { it.name }
                        )

                        if (loot.egg != null) {
                            add("Ovo de companheiro")
                        }
                    }

                if (nomesRecompensas.isNotEmpty()) {
                    pendingLevelMessage +=
                        "\nRecompensas: ${nomesRecompensas.joinToString(", ")}"
                }
            }

        } else {

            hero = state.hero
            pendingLevelMessage = ""
        }

        combat = null

        estadoMundo =
            TransicaoMundo.finalizarCombate(
                estadoMundo
            )

        encounter = null

        message = pendingLevelMessage
    }

    Scaffold(
        topBar = {
            if (combat == null) {
                TopAppBarCompat("Ascensão do Soberano")
            }
        },

        bottomBar = {
            if (combat == null) {
                NavigationBar {
                    listOf(
                        "Personagem",
                        "Multiplayer",
                        "Mundo",
                        "Bestiário"
                    ).forEachIndexed { index, title ->

                        NavigationBarItem(
                            selected = page == index,
                            onClick = {
                                page = index
                            },
                            icon = {},
                            label = {
                                Text(title)
                            }
                        )
                    }
                }
            }
        }

    ) { padding ->

        Column(
            modifier = if (combat != null) {
                Modifier.fillMaxSize()
            } else {
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .padding(16.dp)
            },

            verticalArrangement = if (combat != null) {
                Arrangement.Top
            } else {
                Arrangement.spacedBy(12.dp)
            }

        ) {

            when {

                // BESTIÁRIO
                page == 3 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    item {
                        Text(
                            "BESTIÁRIO",
                            style = MaterialTheme.typography.titleLarge
                        )

                        Text(
                            "Criaturas descobertas durante suas explorações."
                        )
                    }

                    if (carregandoBestiario) {
                        item {
                            CircularProgressIndicator()
                        }

                    } else if (bestiario.isEmpty()) {
                        item {
                            Text(
                                "Você ainda não descobriu nenhuma criatura."
                            )
                        }

                    } else {
                        items(bestiario) { criatura ->

                            Card(
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {

                                    Text(
                                        criatura.nome,
                                        style = MaterialTheme.typography.titleMedium
                                    )

                                    Text(
                                        "Rank: ${criatura.rank} • Nível: ${criatura.nivel}"
                                    )

                                    Text("Raridade: ${criatura.raridade}")
                                    Text("Bioma: ${criatura.bioma}")
                                    Text("Habitat: ${criatura.habitat}")
                                    Text(criatura.descricao)

                                    if (criatura.chefe) {
                                        Text("CHEFE")
                                    }

                                    Text(
                                        "Habilidades: ${
                                            criatura.habilidades.joinToString(", ")
                                                .ifBlank { "Nenhuma registrada" }
                                        }"
                                    )
                                }
                            }
                        }
                    }
                }

                // PERSONAGEM
                page == 0 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    item {
                        Text(
                            profile.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    item {
    if (contaVisitante) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {

                Text(
                    "CONTA DE VISITANTE",
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    "Vincule um e-mail e uma senha para proteger " +
                    "seu personagem e continuar jogando em outros dispositivos."
                )

                if (!mostrarVinculacao) {

                    Button(
                        onClick = {
                            mostrarVinculacao = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("VINCULAR CONTA")
                    }

                } else {

                    OutlinedTextField(
                        value = emailVinculacao,
                        onValueChange = {
                            emailVinculacao = it
                        },
                        label = {
                            Text("E-mail")
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = senhaVinculacao,
                        onValueChange = {
                            senhaVinculacao = it
                        },
                        label = {
                            Text("Senha")
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (vinculandoConta) return@Button

                            scope.launch {
                                vinculandoConta = true

                                try {
                                    AutenticacaoJogador.vincularConta(
                                        emailVinculacao.trim(),
                                        senhaVinculacao
                                    )

                                    contaVisitante = false
                                    mostrarVinculacao = false
                                    emailVinculacao = ""
                                    senhaVinculacao = ""

                                    message =
                                        "Conta vinculada com sucesso! " +
                                        "Seu personagem e seu progresso foram preservados."

                                } catch (e: Exception) {

                                    message =
                                        "Não foi possível vincular a conta: " +
                                        (e.localizedMessage
                                            ?: "Verifique o e-mail e tente novamente.")
                                } finally {
                                    vinculandoConta = false
                                }
                            }
                        },
                        enabled = emailVinculacao.isNotBlank() &&
                            senhaVinculacao.length >= 6 &&
                            !vinculandoConta,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (vinculandoConta) {
                                "VINCULANDO..."
                            } else {
                                "CONFIRMAR VINCULAÇÃO"
                            }
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            mostrarVinculacao = false
                            emailVinculacao = ""
                            senhaVinculacao = ""
                        },
                        enabled = !vinculandoConta,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CANCELAR")
                    }

                    if (vinculandoConta) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

                    item {
                        Text("Nível ${profile.level} • XP ${profile.xp}")
                    }

                    item {
                        LinearProgressIndicator(
                            progress = { xpProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Text(
                            "${(xpProgress * 100).toInt()}% de progresso para o próximo nível"
                        )
                    }

                    item {
                        Text(
                            "Próximo nível: ${nextLevelXp - profile.xp} XP restantes"
                        )
                    }

                    item {
                        Text("Classe: ${profile.characterClass.name}")
                        Text(profile.characterClass.description)
                    }

                    item {
                        Text(
                            "ATRIBUTOS DE COMBATE",
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text("Vida: ${hero.hp}/${hero.maxHp}")
                        Text("Mana: ${hero.mana}/${hero.maxMana}")
                        Text("Ataque: ${hero.attack}")
                        Text("Poder mágico: ${hero.magicPower}")
                        Text("Defesa: ${hero.defense}")
                        Text("Agilidade: ${hero.agility}")
                        Text("Rank: ${hero.rank}")
                    }

                    item {
                        Text(
                            "ATRIBUTOS DO PERSONAGEM",
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text(
                            "Pontos disponíveis: ${profile.attributePoints}"
                        )
                    }

                    item {
                        Text("Força: ${profile.attributes.strength}")

                        Button(
                            onClick = {
                                allocateAttribute("forca")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar força")
                        }
                    }

                    item {
                        Text("Inteligência: ${profile.attributes.intelligence}")

                        Button(
                            onClick = {
                                allocateAttribute("inteligencia")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar inteligência")
                        }
                    }

                    item {
                        Text("Agilidade: ${profile.attributes.agility}")

                        Button(
                            onClick = {
                                allocateAttribute("agilidade")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar agilidade")
                        }
                    }

                    item {
                        Text("Vitalidade: ${profile.attributes.vitality}")

                        Button(
                            onClick = {
                                allocateAttribute("vitalidade")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar vitalidade")
                        }
                    }

                    item {
                        Text("Espírito: ${profile.attributes.spirit}")

                        Button(
                            onClick = {
                                allocateAttribute("espirito")
                            },
                            enabled = profile.attributePoints > 0
                        ) {
                            Text("Aumentar espírito")
                        }
                    }

                    // OVOS DE COMPANHEIROS
                    item {
                        Text(
                            "OVOS DE COMPANHEIROS",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    if (playerInventory.eggs.isEmpty()) {
                        item {
                            Text("Você ainda não possui ovos.")
                        }
                    } else {
                        items(
                            items = playerInventory.eggs,
                            key = { it.id }
                        ) { ovo ->

                            Card(
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {

                                    Text(
                                        ovo.species,
                                        style = MaterialTheme.typography.titleMedium
                                    )

                                    Text("Rank: ${ovo.rank}")
                                    Text("Quantidade: ${ovo.quantity}")
                                    Text("Mutação: ${ovo.mutationName}")
                                    Text("Raridade: ${ovo.mutationRarity}")
                                    Text(ovo.mutationDescription)

                                    Button(
                                        onClick = {
                                            if (eclodindoOvoId != null) {
                                                return@Button
                                            }

                                            scope.launch {
                                                eclodindoOvoId = ovo.id

                                                try {
                                                    val resultado =
                                                        CompanionHatchingSystem.hatchEgg(
                                                            inventory = playerInventory,
                                                            eggId = ovo.id
                                                        )

                                                    if (resultado.success) {
                                                        atualizarInventario(
                                                            resultado.inventory
                                                        )
                                                    }

                                                    message = resultado.message

                                                } catch (e: Exception) {
                                                    message =
                                                        "Erro ao eclodir ovo: ${e.localizedMessage}"
                                                } finally {
                                                    eclodindoOvoId = null
                                                }
                                            }
                                        },
                                        enabled = eclodindoOvoId == null,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            if (eclodindoOvoId == ovo.id) {
                                                "ECLODINDO..."
                                            } else {
                                                "ECLODIR OVO"
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // COMPANHEIROS
                    item {
                        Text(
                            "COMPANHEIROS",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    if (playerInventory.companions.isEmpty()) {
                        item {
                            Text("Você ainda não possui companheiros.")
                        }
                    } else {
                        items(
                            items = playerInventory.companions,
                            key = { it.id }
                        ) { companion ->

                            Card {
                                Column(
                                    Modifier.padding(12.dp)
                                ) {

                                    Text(
                                        "${companion.name} — Rank ${companion.rank}"
                                    )

                                    Text("Nível ${companion.level}")
                                    Text("Estágio: ${companion.stage}")
                                    Text("Mutação: ${companion.mutationName}")
                                    Text("Vida: ${companion.hp}/${companion.maxHp}")
                                    Text("Ataque: ${companion.attack}")
                                    Text("Defesa: ${companion.defense}")

                                    if (companion.isActive) {
                                        Text("Companheiro ativo")
                                    }

                                    Row {

                                        Button(
                                            onClick = {

                                                val updated =
                                                    InventorySystem.ativarCompanheiro(
                                                        playerInventory,
                                                        companion.id
                                                    )

                                                atualizarInventario(updated)
                                            }
                                        ) {
                                            Text("Ativar")
                                        }

                                        OutlinedButton(
                                            onClick = {

                                                val updated =
                                                    InventorySystem.retirarCompanheiro(
                                                        playerInventory
                                                    )

                                                atualizarInventario(updated)
                                            },
                                            enabled = companion.isActive
                                        ) {
                                            Text("Retirar")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // COMBATE INTEGRADO AO MUNDO
                estadoMundo.modo == ModoCenaMundo.COMBATE &&
                    combat != null -> {

                    TelaMundo(
                        estado = estadoMundo,
                        aoAtualizarEstado = {
                            estadoMundo = it
                        },
                        companheiro = InventorySystem.obterCompanheiroAtivo(
                            playerInventory
                        ),
                        modifier = Modifier.fillMaxSize(),
                        conteudoCombate = { areaCombate ->

                            combat?.let { state ->

                                TelaCombate(
                                    state = state,

                                    companion = InventorySystem.obterCompanheiroAtivo(
                                        playerInventory
                                    ),

                                    modifier = areaCombate,
                                    integradoAoMapa = true,

                                    onAttack = {

                                        val updatedCombat =
                                            CombatSystem.playerAttack(state)

                                        observePowerAction(
                                            action = "Realizou um ataque físico",
                                            category = "fisico",
                                            intensity = 10
                                        )

                                        combat = updatedCombat
                                    },

                                    onDefend = {

                                        val updatedCombat =
                                            CombatSystem.playerDefend(state)

                                        observePowerAction(
                                            action = "Realizou uma defesa em combate",
                                            category = "defesa",
                                            intensity = 10
                                        )

                                        combat = updatedCombat
                                        hero = updatedCombat.hero
                                    },

                                    onEnemyTurn = {

                                        val updated =
                                            CombatSystem.enemyAttack(state)

                                        combat = updated
                                        hero = updated.hero
                                    },

                                    onEndCombat = {
                                        finalizarCombate(state)
                                    }
                                )
                            }
                        }
                    }
                }

                // MULTIPLAYER
                page == 1 -> Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    Text(
                        "MULTIPLAYER",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        "Crie campanhas e convide seus amigos."
                    )

                    Button(
                        onClick = {

                            scope.launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()

                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()

                                    val id = db.collection("campaigns")
                                        .document().id

                                    val inviteCode = (1..6)
                                        .map { ('A'..'Z').random() }
                                        .joinToString("")

                                    db.collection("campaigns")
                                        .document(id)
                                        .set(
                                            mapOf(
                                                "ownerUid" to user.uid,
                                                "inviteCode" to inviteCode,
                                                "name" to "Campanha de ${profile.name}",
                                                "visibility" to "private",
                                                "members" to listOf(user.uid),
                                                "createdAt" to System.currentTimeMillis()
                                            )
                                        ).await()

                                    invite = inviteCode
                                    message =
                                        "Campanha criada! Código: $inviteCode"

                                } catch (e: Exception) {
                                    message =
                                        "Erro online: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CRIAR CAMPANHA")
                    }

                    if (invite.isNotBlank()) {
                        Text("Código de convite: $invite")
                    }

                    OutlinedTextField(
                        value = code,
                        onValueChange = {
                            code = it
                        },
                        label = {
                            Text("Código do amigo")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {

                            scope.launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()

                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    if (user == null) {
                                        error("Autenticação falhou.")
                                    }

                                    val db = FirebaseFirestore.getInstance()

                                    val result = db.collection("campaigns")
                                        .whereEqualTo(
                                            "inviteCode",
                                            code.trim().uppercase()
                                        )
                                        .limit(1)
                                        .get()
                                        .await()

                                    val campaign =
                                        result.documents.firstOrNull()
                                            ?: error("Código não encontrado.")

                                    campaign.reference.update(
                                        "members",
                                        com.google.firebase.firestore.FieldValue
                                            .arrayUnion(user.uid)
                                    ).await()

                                    message = "Você entrou na campanha!"

                                } catch (e: Exception) {
                                    message =
                                        "Erro ao entrar: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ENTRAR NA CAMPANHA")
                    }
                }

                // MUNDO ABERTO
                page == 2 -> Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {

                    if (showWorldMap) {

                        TelaMapaMundi(
                            localAtualId = profile.currentWorldPointId,

                            aoSelecionarDestino = { plan ->

                                pendingTravelPlan = plan
                                message = "Registrando viagem..."

                                scope.launch {
                                    try {
                                        val currentProfile =
                                            characterProfile ?: profile

                                        val updatedProfile =
                                            currentProfile.copy(
                                                currentWorldPointId =
                                                    plan.destination.id,
                                                inventory = playerInventory
                                            )

                                        saveMutex.withLock {
                                            CharacterProfileRepository().save(
                                                updatedProfile
                                            )
                                        }

                                        characterProfile = updatedProfile
                                        pendingTravelPlan = null
                                        showWorldMap = false

                                        message =
                                            "Você chegou a ${plan.destination.name}!"

                                    } catch (e: Exception) {
                                        message =
                                            "Não foi possível salvar a viagem: ${e.localizedMessage}"
                                    }
                                }
                            },

                            aoVoltar = {
                                showWorldMap = false
                            },

                            modifier = Modifier.fillMaxSize()
                        )

                    } else {

                        TelaMundo(
                            estado = estadoMundo,
                            aoAtualizarEstado = {
                                estadoMundo = it
                            },
                            companheiro = InventorySystem.obterCompanheiroAtivo(
                                playerInventory
                            ),
                            modifier = Modifier.fillMaxSize()
                        )

                        Card(
                            modifier = Modifier
                                .align(androidx.compose.ui.Alignment.TopCenter)
                                .fillMaxWidth()
                                .padding(8.dp)
                        ) {

                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {

                                Button(
                                    onClick = {
                                        showWorldMap = true
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("ABRIR MAPA-MÚNDI")
                                }

                                Text(
                                    "MUNDO ABERTO",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Text("Região: ${selectedRegion.name}")
                                Text("Escolha uma região:")

                                ExplorationSystem.regions.forEach { region ->

                                    Button(
                                        onClick = {
                                            selectedRegion = region
                                            encounter = null

                                            estadoMundo =
                                                TransicaoMundo.entrarNaExploracao(
                                                    estadoMundo
                                                )
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            "${region.name} — Rank ${region.rank}"
                                        )
                                    }
                                }

                                Button(
                                    onClick = {

                                        estadoMundo =
                                            TransicaoMundo.entrarNaExploracao(
                                                estadoMundo
                                            )

                                        scope.launch {
                                            try {
                                                encounter =
                                                    ExplorationSystem.explore(
                                                        selectedRegion
                                                    )

                                                val criaturaEncontrada =
                                                    encounter?.criatura

                                                val uidJogador =
                                                    FirebaseAuth.getInstance()
                                                        .currentUser?.uid

                                                if (
                                                    criaturaEncontrada != null &&
                                                    uidJogador != null
                                                ) {
                                                    try {
                                                        RepositorioCriaturas.registrarDescoberta(
                                                            uid = uidJogador,
                                                            criatura = criaturaEncontrada
                                                        )

                                                        message =
                                                            "Exploração concluída. Criatura registrada no bestiário!"

                                                    } catch (e: Exception) {
                                                        message =
                                                            "Criatura encontrada, mas não foi possível salvar no bestiário: ${e.localizedMessage}"
                                                    }

                                                } else {
                                                    message =
                                                        "Exploração concluída."
                                                }

                                            } catch (e: Exception) {
                                                message =
                                                    "Erro ao explorar região: ${e.localizedMessage}"
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("EXPLORAR REGIÃO")
                                }

                                encounter?.let { result ->

                                    Text(result.message)

                                    Text(
                                        "Evento: ${result.worldEvent?.title ?: "Nenhum"}"
                                    )

                                    Text(
                                        "Criatura: ${result.criatura?.nome ?: "Nenhuma"}"
                                    )

                                    Text(
                                        "Chefe: ${if (result.isBoss) "Sim" else "Não"}"
                                    )

                                    result.criatura?.let { criatura ->

                                        Button(
                                            onClick = {

                                                combateFinalizado = false

                                                combat =
                                                    CombatFactory.createCombat(
                                                        hero,
                                                        criatura
                                                    )

                                                estadoMundo =
                                                    TransicaoMundo.iniciarCombate(
                                                        estadoMundo
                                                    )

                                                message = "Combate iniciado!"
                                            },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("ENFRENTAR CRIATURA")
                                        }
                                    }

                                    if (result.enemyId != null &&
                                        result.criatura == null
                                    ) {

                                        Button(
                                            onClick = {

                                                combateFinalizado = false

                                                combat =
                                                    CombatFactory.createCombat(
                                                        hero,
                                                        result.enemyId
                                                    )

                                                if (combat != null) {

                                                    estadoMundo =
                                                        TransicaoMundo.iniciarCombate(
                                                            estadoMundo
                                                        )

                                                    message = "Combate iniciado!"

                                                } else {
                                                    message =
                                                        "Não foi possível criar o combate."
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("ENFRENTAR CRIATURA")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                else -> {
                    Text("Selecione uma tela.")
                }
            }
        }
    }
}
