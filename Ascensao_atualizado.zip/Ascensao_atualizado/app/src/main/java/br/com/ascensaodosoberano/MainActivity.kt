
package br.com.ascensaodosoberano

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.ascensaodosoberano.character.CharacterProfile
import br.com.ascensaodosoberano.character.CharacterCreationScreen
import br.com.ascensaodosoberano.exploration.ExplorationSystem
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { FirebaseApp.initializeApp(this) }
        setContent {
            MaterialTheme {
                GameApp()
            }
        }
    }
}

data class Power(
    val name: String,
    val cost: String,
    val detail: String
)

@Composable
fun GameApp() {
    var page by remember { mutableStateOf(0) }
    var message by remember {
        mutableStateOf("Bem-vindo ao Ascensão do Soberano!")
    }
    var invite by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    var characterProfile by remember {
        mutableStateOf<CharacterProfile?>(null)
    }

    if (characterProfile == null) {
        CharacterCreationScreen(
            onCharacterCreated = {
                characterProfile = it
            }
        )
        return
    }

    val hero = characterProfile!!

    var selectedRegion by remember {
        mutableStateOf(ExplorationSystem.regions.first())
    }

    var encounter by remember {
        mutableStateOf<br.com.ascensaodosoberano.exploration.ExplorationEncounter?>(null)
    }

    val powers = remember {
        listOf(
            Power(
                "Punhos da Calamidade Cósmica",
                "0 Mana",
                "Dano físico-base ainda não consolidado. Chamas integradas: 450 inicial + 90 por acúmulo/turno; até 6 acúmulos por 6 turnos."
            ),
            Power(
                "Eclipse do Soberano Abissal",
                "100 Mana",
                "2.250 de dano-base por alvo; alcance/raio 150 m; recarga 5 turnos."
            ),
            Power(
                "Manipulação Gravitacional",
                "A confirmar",
                "Puxar, conter, interromper ou comprimir; custo e recarga não consolidados."
            ),
            Power(
                "Domínio da Calamidade",
                "A confirmar",
                "Controle de área e bloqueio dimensional; parâmetros não consolidados."
            )
        )
    }
    Scaffold(
        topBar = {
            TopAppBarCompat("Ascensão do Soberano")
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    "Personagem",
                    "Combate",
                    "Multiplayer",
                    "Mundo"
                ).forEachIndexed { i, title ->
                    NavigationBarItem(
                        selected = page == i,
                        onClick = { page = i },
                        icon = {},
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { pad ->

        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            when (page) {

                // PERSONAGEM
                0 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            hero.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    item {
                        Text("Nível ${hero.level} • XP ${hero.xp}")
                    }

                    item {
                        Text("Classe: ${hero.characterClass.name}")
                    }

                    item {
                        Text(hero.characterClass.description)
                    }

                    item {
                        Text("AFINIDADES E ESPECIALIDADES")
                    }

                    items(
                        hero.characterClass.affinities.entries.toList()
                    ) { entry ->
                        Text("${entry.key}: ${entry.value}")
                    }
                }

                // COMBATE
                1 -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            "Combate e poderes",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    items(powers) { power ->
                        Card {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    power.name,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text("Custo: ${power.cost}")
                                Text(power.detail)
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                message =
                                    "D20: ${Random.nextInt(1, 21)}. Defina CD e modificadores antes de resolver."
                            }
                        ) {
                            Text("Rolar D20")
                        }
                    }
                }

                // MULTIPLAYER
                2 -> Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Campanhas individuais + convites",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        "Cada jogador preserva sua campanha. Amigos podem entrar em sessões cooperativas convidadas."
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    val db = FirebaseFirestore.getInstance()

                                    if (user == null) {
                                        error("Autenticação não retornou usuário")
                                    }

                                    val id = db.collection("campaigns")
                                        .document().id

                                    val codeGen = (1..6)
                                        .map { ('A'..'Z').random() }
                                        .joinToString("")

                                    db.collection("campaigns")
                                        .document(id)
                                        .set(
                                            mapOf(
                                                "ownerUid" to user.uid,
                                                "inviteCode" to codeGen,
                                                "name" to "Campanha de ${hero.name}",
                                                "visibility" to "private",
                                                "members" to listOf(user.uid),
                                                "createdAt" to System.currentTimeMillis()
                                            )
                                        )
                                        .await()

                                    invite = codeGen
                                    message =
                                        "Campanha criada. Compartilhe o código $codeGen."

                                } catch (e: Exception) {
                                    message =
                                        "Online indisponível: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Criar campanha e gerar convite")
                    }

                    if (invite.isNotBlank()) {
                        Text(
                            "Convite: $invite",
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }

                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("Código do amigo") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    val auth = FirebaseAuth.getInstance()
                                    val user = auth.currentUser
                                        ?: auth.signInAnonymously().await().user

                                    val db = FirebaseFirestore.getInstance()

                                    if (user == null) {
                                        error("Autenticação falhou")
                                    }

                                    val q = db.collection("campaigns")
                                        .whereEqualTo(
                                            "inviteCode",
                                            code.trim().uppercase()
                                        )
                                        .limit(1)
                                        .get()
                                        .await()

                                    val doc = q.documents.firstOrNull()
                                        ?: error("Código não encontrado")

                                    doc.reference.update(
                                        "members",
                                        com.google.firebase.firestore.FieldValue
                                            .arrayUnion(user.uid)
                                    ).await()

                                    message =
                                        "Entrada confirmada na campanha ${doc.getString("name")}."

                                } catch (e: Exception) {
                                    message =
                                        "Não foi possível entrar: ${e.localizedMessage}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Entrar na campanha")
                    }
                }

                // MUNDO ABERTO
                else -> Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "MUNDO ABERTO",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text("Escolha uma região para explorar:")

                    ExplorationSystem.regions.forEach { region ->
                        Button(
                            onClick = {
                                selectedRegion = region
                                encounter = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${region.name} — Rank ${region.rank}")
                        }
                    }

                    Text("Região selecionada: ${selectedRegion.name}")

                    Button(
                        onClick = {
                            encounter = ExplorationSystem.explore(selectedRegion)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("EXPLORAR REGIÃO")
                    }

                    encounter?.let { result ->
                        Card {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(result.message)
                                Text("Evento: ${result.worldEvent?.title ?: "Nenhum"}")
                                Text("Inimigo: ${result.enemyId ?: "Nenhum"}")
                                Text("Chefe: ${if (result.isBoss) "Sim" else "Não"}")
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            Text(
                message,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String) {
    TopAppBar(
        title = { Text(title) }
    )
}
