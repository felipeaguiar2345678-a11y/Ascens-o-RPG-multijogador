
package br.com.ascensaodosoberano.world

import kotlin.random.Random

enum class WorldEventType {
    ENCOUNTER,
    BOSS,
    QUEST,
    NPC,
    TREASURE,
    NOTHING
}

data class WorldContext(
    val regionName: String,
    val regionRank: String,
    val dangerLevel: Int = 1
)

data class WorldEvent(
    val type: WorldEventType,
    val title: String,
    val description: String,
    val threatLevel: Int,
    val rewards: List<String> = emptyList()
)

object WorldDirector {

    fun generateEvent(context: WorldContext): WorldEvent {

        val danger = context.dangerLevel.coerceIn(1, 100)
        val roll = Random.nextInt(1, 101)

        return when {
            roll <= danger / 5 -> WorldEvent(
                type = WorldEventType.BOSS,
                title = "Presença Colossal",
                description = "Uma entidade poderosa despertou em ${context.regionName}.",
                threatLevel = danger,
                rewards = listOf("Recompensa de chefe", "Experiência")
            )

            roll <= danger -> WorldEvent(
                type = WorldEventType.ENCOUNTER,
                title = "Inimigo Detectado",
                description = "Uma criatura hostil apareceu em ${context.regionName}.",
                threatLevel = danger
            )

            roll <= danger + 20 -> WorldEvent(
                type = WorldEventType.QUEST,
                title = "Novo Pedido",
                description = "Uma oportunidade de missão surgiu na região.",
                threatLevel = danger / 2,
                rewards = listOf("Experiência", "Possíveis itens")
            )

            roll <= danger + 40 -> WorldEvent(
                type = WorldEventType.TREASURE,
                title = "Vestígio Esquecido",
                description = "Você encontrou sinais de um tesouro em ${context.regionName}.",
                threatLevel = danger / 3,
                rewards = listOf("Tesouro desconhecido")
            )

            roll <= danger + 60 -> WorldEvent(
                type = WorldEventType.NPC,
                title = "Viajante Encontrado",
                description = "Um personagem misterioso está próximo.",
                threatLevel = 0
            )

            else -> WorldEvent(
                type = WorldEventType.NOTHING,
                title = "Exploração Tranquila",
                description = "Nenhum acontecimento especial foi detectado.",
                threatLevel = 0
            )
        }
    }
}
