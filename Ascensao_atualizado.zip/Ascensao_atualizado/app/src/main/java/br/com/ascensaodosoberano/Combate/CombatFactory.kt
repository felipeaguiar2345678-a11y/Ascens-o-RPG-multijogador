
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.world.BalanceEngine

object CombatFactory {

    private fun levelByRank(rank: String): Int {
        return when (rank.uppercase()) {
            "E" -> 1
            "D" -> 5
            "C" -> 10
            "B" -> 20
            "A" -> 35
            "S" -> 50
            "SS" -> 70
            "SSS" -> 100
            else -> 1
        }
    }

    fun createCombat(
        hero: Combatant,
        enemyId: String
    ): CombatState? {

        val data = EnemyDatabase.getById(enemyId)
            ?: return null

        val enemyLevel = levelByRank(data.rank)

        val danger = BalanceEngine.generateDanger(
            enemyRank = data.rank,
            isBoss = data.isBoss
        )

        val enemyMana = if (data.isBoss) {
            data.maxHp / 20
        } else {
            data.maxHp / 50
        }

        val enemy = Combatant(
            name = data.name,
            maxHp = data.maxHp,
            hp = data.maxHp,
            attack = data.attack,
            defense = data.defense,
            mana = enemyMana,
            maxMana = enemyMana,
            rank = data.rank,
            level = enemyLevel,
            danger = danger,
            xpReward = data.xpReward,
            isBoss = data.isBoss
        )

        return CombatSystem.startCombat(
            hero = hero,
            enemy = enemy
        )
    }
}
