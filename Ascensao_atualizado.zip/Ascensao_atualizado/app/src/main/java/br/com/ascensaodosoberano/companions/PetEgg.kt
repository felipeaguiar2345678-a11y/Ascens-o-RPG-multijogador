
package br.com.ascensaodosoberano.companions

data class PetEgg(
    val id: String,
    val species: String,
    val monsterId: String,
    val rank: String,
    val imageKey: String,
    val hatchChance: Int,
    val quantity: Int = 1,
    val imagemIconeCaminho: String = "",
    val imagemDetalhadaCaminho: String = ""
)

object PetEggSystem {

    fun getDropChance(rank: String): Int {
        return when (rank.uppercase()) {
            "E" -> 5
            "D" -> 4
            "C" -> 3
            "B" -> 2
            "A" -> 2
            "S" -> 1
            "SS" -> 1
            "SSS" -> 1
            else -> 1
        }
    }

    fun rollEggDrop(
        monsterId: String,
        species: String,
        rank: String,
        imageKey: String
    ): PetEgg? {

        val chance = getDropChance(rank)

        val roll = (1..100).random()

        if (roll > chance) return null

        return PetEgg(
            id = "${monsterId}_${System.currentTimeMillis()}",
            species = species,
            monsterId = monsterId,
            rank = rank,
            imageKey = imageKey,
            hatchChance = 100
        )
    }
}
