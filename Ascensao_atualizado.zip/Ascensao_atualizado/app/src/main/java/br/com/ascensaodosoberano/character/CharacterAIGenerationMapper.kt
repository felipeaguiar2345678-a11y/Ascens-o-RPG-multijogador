
package br.com.ascensaodosoberano.character

object CharacterAIGenerationMapper {

    fun toMap(
        generation: CharacterAIGeneration
    ): Map<String, Any> {

        return mapOf(
            "characterId" to generation.characterId,
            "generationId" to generation.generationId,
            "prompt" to generation.prompt,
            "status" to generation.status.name,
            "imagePath" to generation.imagePath,
            "imageUrl" to generation.imageUrl,
            "visualVersion" to generation.visualVersion,
            "errorMessage" to generation.errorMessage
        )
    }
}
