package br.com.ascensaodosoberano.character

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CharacterAppearancePreview(
    appearance: CharacterAppearance,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (appearance.generatedImageUrl.isNotBlank()) {
                Text("Imagem do personagem será carregada aqui")
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Pré-visualização",
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text("Pele: ${appearance.skinId}")
                    Text("Cabelo: ${appearance.hairId}")
                    Text("Olhos: ${appearance.eyeId}")
                    Text("Roupa: ${appearance.outfitId}")

                    Text("Aguardando geração da aparência pela IA")
                }
            }
        }
    }
}