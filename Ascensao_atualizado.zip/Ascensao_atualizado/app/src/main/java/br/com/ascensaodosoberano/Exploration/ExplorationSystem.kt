
package br.com.ascensaodosoberano.exploration

import br.com.ascensaodosoberano.world.CriaturaGerada
import br.com.ascensaodosoberano.world.CreatureApi
import br.com.ascensaodosoberano.world.RepositorioCriaturas
import br.com.ascensaodosoberano.world.WorldContext
import br.com.ascensaodosoberano.world.WorldDirector
import br.com.ascensaodosoberano.world.WorldEvent
import br.com.ascensaodosoberano.world.WorldEventType

enum class RegionRank {
    E, D, C, B, A, S, SS, SSS
}

data class ExplorationRegion(
    val id: String,
    val name: String,
    val rank: RegionRank,
    val encounterChance: Int,
    val bossChance: Int,
    val ecosystemId: String = "unknown",
    val biome: String = "unknown"
)

data class ExplorationEncounter(
    val region: ExplorationRegion,
    val enemyId: String?,
    val isBoss: Boolean,
    val message: String,
    val worldEvent: WorldEvent? = null,
    val criatura: CriaturaGerada? = null
)

object ExplorationSystem {

    val regions = listOf(
        ExplorationRegion(
            "dark_forest",
            "Floresta das Sombras",
            RegionRank.E,
            45,
            5,
            ecosystemId = "dark_forest",
            biome = "floresta sombria"
        ),
        ExplorationRegion(
            "forgotten_ruins",
            "Ruínas Esquecidas",
            RegionRank.C,
            60,
            10,
            ecosystemId = "forgotten_ruins",
            biome = "ruínas antigas"
        ),
        ExplorationRegion(
            "abyss_valley",
            "Vale do Abismo",
            RegionRank.S,
            75,
            20,
            ecosystemId = "abyss_valley",
            biome = "vale abissal"
        ),
        ExplorationRegion(
            "dead_lands",
            "Terras Mortas de Nhar-Zul",
            RegionRank.SSS,
            90,
            30,
            ecosystemId = "dead_lands",
            biome = "terras mortas"
        )
    )

    suspend fun explore(
        region: ExplorationRegion
    ): ExplorationEncounter {

        val event = WorldDirector.generateEvent(
            WorldContext(
                regionName = region.name,
                regionRank = region.rank.name,
                dangerLevel = region.encounterChance,
                bossChance = region.bossChance,
                ecosystemId = region.ecosystemId,
                biome = region.biome
            )
        )

        val rankLimit = region.rank.ordinal

        val criaturas = RepositorioCriaturas
            .buscarPorEcossistema(region.ecosystemId)
            .filter { criatura ->
                val rank = runCatching {
                    RegionRank.valueOf(criatura.rank.uppercase())
                }.getOrNull()

                rank != null && rank.ordinal <= rankLimit
            }

        fun correspondeAoEvento(
            criatura: CriaturaGerada
        ): Boolean {
            return when (event.type) {
                WorldEventType.BOSS -> criatura.chefe
                WorldEventType.ENCOUNTER -> !criatura.chefe
                else -> false
            }
        }

        val candidatas = criaturas.filter {
            correspondeAoEvento(it)
        }

        var selecionada = candidatas.randomOrNull()

        // Só tenta gerar quando não existe criatura adequada.
        if (
            selecionada == null &&
            (event.type == WorldEventType.BOSS ||
             event.type == WorldEventType.ENCOUNTER)
        ) {
            val gerada = runCatching {
                val status = CreatureApi.checkHealth()

                if (
                    status.success &&
                    status.body.optBoolean("aiConfigured", false)
                ) {
                    CreatureApi.gerarERegistrarCriatura(
    ecosystemId = region.ecosystemId,
    biome = region.biome,
    rank = region.rank.name,
    danger = region.encounterChance,
    isBoss = event.type == WorldEventType.BOSS,
    bossChance = region.bossChance
)
                } else {
                    null
                }
            }.getOrNull()

            selecionada = gerada?.takeIf { criatura ->
                val rank = runCatching {
                    RegionRank.valueOf(criatura.rank.uppercase())
                }.getOrNull()

                rank != null &&
                    rank.ordinal <= rankLimit &&
                    correspondeAoEvento(criatura)
            }
        }

        return ExplorationEncounter(
            region = region,
            enemyId = selecionada?.id,
            isBoss = selecionada?.chefe == true,
            message = when {
                selecionada == null -> event.description
                selecionada.chefe ->
                    "CHEFE ENCONTRADO: ${selecionada.nome}!"
                else ->
                    "CRIATURA ENCONTRADA: ${selecionada.nome}!"
            },
            worldEvent = event,
            criatura = selecionada
        )
    }
}
