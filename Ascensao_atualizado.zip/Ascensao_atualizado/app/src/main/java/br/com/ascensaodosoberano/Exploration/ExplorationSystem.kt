
package br.com.ascensaodosoberano.exploration

import br.com.ascensaodosoberano.combat.EnemyDatabase
import br.com.ascensaodosoberano.world.WorldContext
import br.com.ascensaodosoberano.world.WorldDirector
import br.com.ascensaodosoberano.world.WorldEvent
import br.com.ascensaodosoberano.world.WorldEventType

enum class RegionRank {
    E, D, C, B, A, S, SS, SSS
}

data class ExplorationRegion(
    val id: String,
    val name: String,
    val rank: RegionRank,
    val encounterChance: Int,
    val bossChance: Int
)

data class ExplorationEncounter(
    val region: ExplorationRegion,
    val enemyId: String?,
    val isBoss: Boolean,
    val message: String,
    val worldEvent: WorldEvent? = null
)

object ExplorationSystem {

    val regions = listOf(
        ExplorationRegion("dark_forest", "Floresta das Sombras", RegionRank.E, 45, 5),
        ExplorationRegion("forgotten_ruins", "Ruínas Esquecidas", RegionRank.C, 60, 10),
        ExplorationRegion("abyss_valley", "Vale do Abismo", RegionRank.S, 75, 20),
        ExplorationRegion("dead_lands", "Terras Mortas de Nhar-Zul", RegionRank.SSS, 90, 30)
    )

    fun explore(region: ExplorationRegion): ExplorationEncounter {
        val event = WorldDirector.generateEvent(
            WorldContext(
                regionName = region.name,
                regionRank = region.rank.name,
                dangerLevel = region.encounterChance
            )
        )

        val rankLimit = region.rank.ordinal

        val normalEnemies = EnemyDatabase.getAll().filter {
            !it.isBoss &&
            RegionRank.valueOf(it.rank).ordinal <= rankLimit
        }

        val bosses = EnemyDatabase.getBosses().filter {
            RegionRank.valueOf(it.rank).ordinal <= rankLimit
        }

        val selectedEnemy = when (event.type) {
            WorldEventType.BOSS -> bosses.randomOrNull()
            WorldEventType.ENCOUNTER -> normalEnemies.randomOrNull()
            else -> null
        }

        return ExplorationEncounter(
            region = region,
            enemyId = selectedEnemy?.id,
            isBoss = selectedEnemy?.isBoss == true,
            message = when {
                selectedEnemy == null -> event.description
                selectedEnemy.isBoss -> "CHEFE ENCONTRADO: ${selectedEnemy.name}!"
                else -> "INIMIGO ENCONTRADO: ${selectedEnemy.name}!"
            },
            worldEvent = event
        )
    }
}
