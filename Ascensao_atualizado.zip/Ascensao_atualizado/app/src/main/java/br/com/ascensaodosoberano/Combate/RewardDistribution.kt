
package br.com.ascensaodosoberano.combat

data class PlayerReward(
    val playerId: String,
    val xp: Int,
    val receivesItems: Boolean
)

object RewardDistributionSystem {

    fun distribute(
        participants: CombatParticipants,
        totalXp: Int
    ): List<PlayerReward> {

        val players = participants.players.filter {
            it.damageDealt > 0
        }

        if (players.isEmpty()) return emptyList()

        val xpPerPlayer = totalXp / players.size
        val remainder = totalXp % players.size

        val topDamageDealers =
            CombatContributionSystem.getTopDamageDealers(
                participants.copy(players = players)
            ).map { it.playerId }.toSet()

        return players.mapIndexed { index, player ->
            PlayerReward(
                playerId = player.playerId,
                xp = xpPerPlayer + if (index < remainder) 1 else 0,
                receivesItems = player.playerId in topDamageDealers
            )
        }
    }
}
