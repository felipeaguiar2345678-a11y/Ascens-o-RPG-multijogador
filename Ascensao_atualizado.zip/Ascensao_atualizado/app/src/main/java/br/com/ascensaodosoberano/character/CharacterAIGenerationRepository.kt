
package br.com.ascensaodosoberano.character

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class CharacterAIGenerationRepository(
    private val db: FirebaseFirestore =
        FirebaseFirestore.getInstance()
) {

        suspend fun save(
        generation: CharacterAIGeneration
    ) {
        val ownerUid = FirebaseAuth.getInstance()
            .currentUser?.uid
            ?: throw IllegalStateException(
                "Usuário precisa estar autenticado."
            )

        val data = CharacterAIGenerationMapper
            .toMap(generation)
            .toMutableMap()

        data["ownerUid"] = ownerUid

        db.collection("characterVisuals")
            .document(generation.characterId)
            .set(data)
            .await()
    }

    suspend fun get(
        characterId: String
    ): CharacterAIGeneration? {

        val document = db.collection("characterVisuals")
            .document(characterId)
            .get()
            .await()

        if (!document.exists()) return null

        val data = document.data ?: return null

        return CharacterAIGenerationMapper.fromMap(data)
    }
}
