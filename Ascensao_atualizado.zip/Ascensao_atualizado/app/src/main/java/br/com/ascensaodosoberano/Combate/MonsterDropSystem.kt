
package br.com.ascensaodosoberano.combat

data class MonsterDropResult(
    val materials: List<br.com.ascensaodosoberano.companions.InventoryItem>,
    val equipment: List<br.com.ascensaodosoberano.companions.Equipment>
)

object MonsterDropSystem {

    fun roll(
        monsterId: String
    ): MonsterDropResult {

        val table = MonsterDropDatabase.getTable(monsterId)
            ?: return MonsterDropResult(
                materials = emptyList(),
                equipment = emptyList()
            )

        val materials = table.materials.mapNotNull { entry ->

            val roll = (1..100).random()

            if (roll > entry.chance) {
                null
            } else {
                entry.item.copy(
                    quantity = (entry.minQuantity..entry.maxQuantity).random()
                )
            }
        }

        val equipment = table.equipment.mapNotNull { entry ->

            val roll = (1..100).random()

            if (roll <= entry.chance) {
                entry.equipment
            } else {
                null
            }
        }

        return MonsterDropResult(
            materials = materials,
            equipment = equipment
        )
    }
}
