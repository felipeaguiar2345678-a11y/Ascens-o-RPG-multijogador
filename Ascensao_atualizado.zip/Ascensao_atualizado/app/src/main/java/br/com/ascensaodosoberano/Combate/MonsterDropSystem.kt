
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.companions.InventoryItem
import br.com.ascensaodosoberano.companions.Equipment
import br.com.ascensaodosoberano.companions.EquipmentType
import br.com.ascensaodosoberano.companions.EquipmentRarity
import br.com.ascensaodosoberano.world.CriaturaGerada
import kotlin.random.Random

data class MonsterDropResult(
    val materials: List<InventoryItem>,
    val equipment: List<Equipment>
)

object MonsterDropSystem {

    fun roll(
        criatura: CriaturaGerada
    ): MonsterDropResult {

        val materials = mutableListOf<InventoryItem>()
        val equipment = mutableListOf<Equipment>()

        criatura.drops.forEach { drop ->

            val sucesso = drop.garantido ||
                Random.nextFloat() * 100f < drop.chancePercentual

            if (!sucesso) return@forEach

            when (drop.tipo.uppercase()) {

                "MATERIAL" -> {

                    val minimo = drop.quantidadeMinima.coerceIn(1, 999)
                    val maximo = drop.quantidadeMaxima
                        .coerceIn(minimo, 999)

                    materials.add(
                        InventoryItem(
                            id = drop.itemId,
                            name = drop.nome,
                            description = drop.descricao,
                            type = "Material de criação",
                            quantity = Random.nextInt(
                                minimo,
                                maximo + 1
                            ),
                            imagemIconeCaminho = "",
                            imagemDetalhadaCaminho = ""
                        )
                    )
                }

                "EQUIPAMENTO" -> {

                    val tipo = runCatching {
                        EquipmentType.valueOf(
                            drop.tipoEquipamento.uppercase()
                        )
                    }.getOrNull() ?: return@forEach

                    val raridade = runCatching {
                        EquipmentRarity.valueOf(
                            drop.raridadeEquipamento.uppercase()
                        )
                    }.getOrNull() ?: return@forEach

                    equipment.add(
                        Equipment(
                            id = drop.itemId,
                            name = drop.nome,
                            description = drop.descricao,
                            type = tipo,
                            rarity = raridade,
                            rank = drop.rankEquipamento,
                            levelRequired = drop.nivelRequerido,
                            attributes = drop.atributos,
                            specialEffect = drop.efeitoEspecial,
                            sourceMonsterId = criatura.id
                        )
                    )
                }
            }
        }

        return MonsterDropResult(
            materials = materials,
            equipment = equipment
        )
    }
}
