
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.companions.Equipment
import br.com.ascensaodosoberano.companions.InventoryItem

data class DropEntry(
    val item: InventoryItem,
    val chance: Int,
    val minQuantity: Int = 1,
    val maxQuantity: Int = 1
)

data class EquipmentDropEntry(
    val equipment: Equipment,
    val chance: Int = 10
)

data class MonsterDropTable(
    val monsterId: String,
    val materials: List<DropEntry> = emptyList(),
    val equipment: List<EquipmentDropEntry> = emptyList()
)
