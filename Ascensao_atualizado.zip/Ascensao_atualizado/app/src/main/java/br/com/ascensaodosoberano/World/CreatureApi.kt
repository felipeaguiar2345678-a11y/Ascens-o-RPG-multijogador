
package br.com.ascensaodosoberano.world

import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class CreatureApiResult(
    val statusCode: Int,
    val body: JSONObject
) {
    val success: Boolean
        get() = statusCode in 200..299

    fun getCreature(): CriaturaGerada? {
        if (!success) return null

        return try {
            CreatureJsonParser.parse(body)
        } catch (e: Exception) {
            null
        }
    }
}

object CreatureApi {

    private const val BASE_URL =
        "https://ascensao-soberano-api.felipeaguiar2345678.workers.dev"

    suspend fun checkHealth(): CreatureApiResult {
        return request("/health", "GET")
    }

    suspend fun requestCreature(
        ecosystemId: String,
        biome: String,
        rank: String,
        danger: Int,
        isBoss: Boolean,
        bossChance: Int
    ): CreatureApiResult {

        val usuario = FirebaseAuth.getInstance().currentUser
            ?: throw IllegalStateException(
                "O jogador precisa estar autenticado."
            )

        val token = usuario.getIdToken(false).await().token
            ?: throw IllegalStateException(
                "Não foi possível obter o token Firebase."
            )

        val payload = JSONObject().apply {
            put("ecosystemId", ecosystemId)
            put("biome", biome)
            put("rank", rank)
            put("danger", danger)
            put("isBoss", isBoss)
            put("bossChance", bossChance)
        }

        return request(
            "/api/creatures/generate",
            "POST",
            payload.toString(),
            token
        )
    }

    suspend fun gerarERegistrarCriatura(
    ecosystemId: String,
    biome: String,
    rank: String,
    danger: Int,
    isBoss: Boolean,
    bossChance: Int
): CriaturaGerada {

        val resposta = requestCreature(
    ecosystemId,
    biome,
    rank,
    danger,
    isBoss,
    bossChance
)

        if (!resposta.success) {
            throw IllegalStateException(
                "Falha na geração da criatura: HTTP ${resposta.statusCode}"
            )
        }

        val criaturaRecebida = resposta.getCreature()
            ?: throw IllegalStateException(
                "A API retornou dados inválidos para a criatura."
            )

        require(criaturaRecebida.ecosystemId == ecosystemId) {
            "A criatura pertence a outro ecossistema."
        }

        val raridadeNormalizada = when (
            criaturaRecebida.raridade.trim().uppercase()
        ) {
            "COMMON" -> "COMUM"
            "UNCOMMON" -> "INCOMUM"
            "RARE" -> "RARO"
            "EPIC" -> "ÉPICO"
            "LEGENDARY" -> "LENDÁRIO"
            "MYTHIC" -> "MÍTICO"
            "WORLD" -> "MUNDO"
            else -> criaturaRecebida.raridade.trim().uppercase()
        }

        return RepositorioCriaturas.registrarCriaturaGlobal(
            criaturaRecebida.copy(
                raridade = raridadeNormalizada
            )
        )
    }

    private suspend fun request(
        path: String,
        method: String,
        body: String? = null,
        authToken: String? = null
    ): CreatureApiResult = withContext(Dispatchers.IO) {

        var connection: HttpURLConnection? = null

        try {
            connection = URL(BASE_URL + path)
                .openConnection() as HttpURLConnection

            connection.requestMethod = method
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            if (authToken != null) {
                connection.setRequestProperty(
                    "Authorization",
                    "Bearer $authToken"
                )
            }

            if (body != null) {
                connection.doOutput = true

                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                )

                connection.outputStream.use {
                    it.write(body.toByteArray(Charsets.UTF_8))
                }
            }

            val status = connection.responseCode

            val stream = if (status in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val responseText = stream
                ?.bufferedReader(Charsets.UTF_8)
                ?.use { it.readText() }
                ?: "{}"

            CreatureApiResult(
                status,
                JSONObject(responseText)
            )

        } catch (e: Exception) {
            CreatureApiResult(
                0,
                JSONObject().apply {
                    put("error", "NETWORK_ERROR")
                    put(
                        "message",
                        e.message ?: "Falha na comunicação com a API."
                    )
                }
            )
        } finally {
            connection?.disconnect()
        }
    }
}
