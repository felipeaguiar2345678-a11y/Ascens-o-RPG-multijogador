
package br.com.ascensaodosoberano.companions

data class InventoryItem(
    val id: String,
    val name: String,
    val description: String,
    val type: String,
    val quantity: Int = 1,
    val imagemIconeCaminho: String = "",
    val imagemDetalhadaCaminho: String = ""
)
object InventorySystem {

    fun addItem(
        inventory: PlayerInventory,
        item: InventoryItem
    ): PlayerInventory {
        val existing = inventory.items.find {
            it.id == item.id
        }

        return if (existing != null) {
            inventory.copy(
                items = inventory.items.map {
                    if (it.id == item.id) {
                        it.copy(quantity = it.quantity + item.quantity)
                    } else {
                        it
                    }
                }
            )
        } else {
            inventory.copy(
                items = inventory.items + item
            )
        }
    }

    fun addEgg(
        inventory: PlayerInventory,
        egg: PetEgg
    ): PlayerInventory {
        return inventory.copy(
            eggs = inventory.eggs + egg
        )
    }

    fun addCompanion(
        inventory: PlayerInventory,
        companion: Companion
    ): PlayerInventory {
        return inventory.copy(
            companions = inventory.companions + companion
        )
    }
            fun addEquipment(
        inventory: PlayerInventory,
        equipment: Equipment
    ): PlayerInventory {
        return inventory.copy(
            equipment = inventory.equipment + equipment
        )
    }
}