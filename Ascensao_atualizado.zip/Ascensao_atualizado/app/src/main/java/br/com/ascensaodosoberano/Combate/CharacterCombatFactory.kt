
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.character.CharacterProfile
import br.com.ascensaodosoberano.character.SkillDomain
import br.com.ascensaodosoberano.character.Affinity

object CharacterCombatFactory {

    fun createHero(profile: CharacterProfile): Combatant {

        val affinities = profile.characterClass.affinities

        fun affinity(domain: SkillDomain): Affinity {
            return affinities[domain] ?: Affinity.MEDIUM
        }

        val levelBonus = (profile.level - 1).coerceAtLeast(0)

        val hpBase = when (affinity(SkillDomain.DEFENSE)) {
            Affinity.HIGH -> 130
            Affinity.MEDIUM -> 115
            Affinity.LOW -> 100
        }

        val manaBase = when (affinity(SkillDomain.MAGIC)) {
            Affinity.HIGH -> 100
            Affinity.MEDIUM -> 70
            Affinity.LOW -> 40
        }

        val attackBase = when (affinity(SkillDomain.PHYSICAL)) {
            Affinity.HIGH -> 30
            Affinity.MEDIUM -> 25
            Affinity.LOW -> 20
        }

        val defenseBase = when (affinity(SkillDomain.DEFENSE)) {
            Affinity.HIGH -> 15
            Affinity.MEDIUM -> 10
            Affinity.LOW -> 5
        }

        val summoningBonus = when (affinity(SkillDomain.SUMMONING)) {
            Affinity.HIGH -> 25
            Affinity.MEDIUM -> 10
            Affinity.LOW -> 0
        }

        return Combatant(
            name = profile.name,
            maxHp = hpBase + levelBonus * 20,
            hp = hpBase + levelBonus * 20,
            attack = attackBase + levelBonus * 3,
            defense = defenseBase + levelBonus * 2,
            mana = manaBase + summoningBonus + levelBonus * 10,
            maxMana = manaBase + summoningBonus + levelBonus * 10,
            rank = "E",
            level = profile.level
        )
    }
}
