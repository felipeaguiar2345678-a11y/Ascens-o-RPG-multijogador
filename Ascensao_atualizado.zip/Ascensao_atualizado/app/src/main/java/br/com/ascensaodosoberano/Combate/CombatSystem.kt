
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.world.AIAction
import br.com.ascensaodosoberano.world.AICombatContext
import br.com.ascensaodosoberano.world.BalanceContext
import br.com.ascensaodosoberano.world.BalanceEngine
import br.com.ascensaodosoberano.world.WorldAI

enum class CombatPhase {
    PLAYER_TURN,
    ENEMY_TURN,
    VICTORY,
    DEFEAT,
    ENEMY_ESCAPED
}

data class Combatant(
    val name: String,
    val maxHp: Int,
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val mana: Int = 0,
    val maxMana: Int = mana,
    val rank: String = "E",
    val level: Int = 1,
    val danger: Int = 30,
    val xpReward: Int = 0,
    val isBoss: Boolean = false,
    val agility: Int = 5,
    val magicPower: Int = 15
) {
    val isAlive: Boolean
        get() = hp > 0
}

data class CombatState(
    val hero: Combatant,
    val enemy: Combatant,
    val phase: CombatPhase = CombatPhase.PLAYER_TURN,
    val turn: Int = 1,
    val log: List<String> = emptyList(),
    val enemyDefending: Boolean = false,
    val playerDefending: Boolean = false,
    val defenseReduction: Int = 0,
    val playerContribution: Float = 1f,
    val xpGained: Int = 0,
    val playerVulnerable: Boolean = false,
    val enemyVulnerable: Boolean = false
)

object CombatSystem {

    fun startCombat(
        hero: Combatant,
        enemy: Combatant
    ): CombatState {
        return CombatState(
            hero = hero,
            enemy = enemy,
            log = listOf("Combate iniciado contra ${enemy.name}!")
        )
    }

    fun playerDefend(state: CombatState): CombatState {
        if (state.phase != CombatPhase.PLAYER_TURN) return state

        val modifier = (
            (state.hero.agility - state.enemy.agility) / 3
        ).coerceIn(-3, 3)

        val dice = DiceSystem.rollD20(modifier)

        val rollLog =
            "Rolagem de defesa: ${dice.naturalRoll} + ${dice.modifier} = ${dice.total}. ${dice.description}"

        return when (dice.outcome) {

            DiceOutcome.CATASTROPHIC_FAILURE ->
                state.copy(
                    phase = CombatPhase.ENEMY_TURN,
                    playerVulnerable = true,
                    playerDefending = false,
                    defenseReduction = 0,
                    log = state.log + rollLog +
                        "Falha catastrófica! Você perdeu o equilíbrio e ficou vulnerável!"
                )

            DiceOutcome.FAILURE,
            DiceOutcome.WEAK_RESULT ->
                state.copy(
                    phase = CombatPhase.ENEMY_TURN,
                    playerDefending = false,
                    defenseReduction = 0,
                    log = state.log + rollLog +
                        "Sua defesa foi insuficiente!"
                )

            DiceOutcome.SUCCESS ->
                state.copy(
                    phase = CombatPhase.ENEMY_TURN,
                    playerDefending = true,
                    defenseReduction = 30,
                    log = state.log + rollLog +
                        "Defesa bem-sucedida! Próximo dano reduzido em 30%."
                )

            DiceOutcome.EXCEPTIONAL_SUCCESS ->
                state.copy(
                    phase = CombatPhase.ENEMY_TURN,
                    playerDefending = true,
                    defenseReduction = 50,
                    log = state.log + rollLog +
                        "Defesa excepcional! Próximo dano reduzido em 50%."
                )

            DiceOutcome.EXTRAORDINARY_SUCCESS ->
                state.copy(
                    phase = CombatPhase.ENEMY_TURN,
                    playerDefending = true,
                    defenseReduction = 75,
                    log = state.log + rollLog +
                        "DEFESA EXTRAORDINÁRIA! Próximo dano reduzido em 75%."
                )
        }
    }

    fun playerAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.PLAYER_TURN) return state

        val modifier = (
            (state.hero.agility - state.enemy.agility) / 3
        ).coerceIn(-3, 3)

        val dice = DiceSystem.rollD20(modifier)

        val rollLog =
            "Rolagem de ataque: ${dice.naturalRoll} + ${dice.modifier} = ${dice.total}. ${dice.description}"

        if (
            dice.outcome == DiceOutcome.CATASTROPHIC_FAILURE ||
            dice.outcome == DiceOutcome.FAILURE ||
            dice.outcome == DiceOutcome.WEAK_RESULT
        ) {
            val catastrophic =
                dice.outcome == DiceOutcome.CATASTROPHIC_FAILURE

            val consequence = if (catastrophic) {
                "Você perdeu o equilíbrio e ficou vulnerável ao inimigo!"
            } else {
                "Seu ataque não acertou o alvo!"
            }

            return state.copy(
                phase = CombatPhase.ENEMY_TURN,
                enemyDefending = false,
                playerVulnerable = state.playerVulnerable || catastrophic,
                log = state.log + rollLog + consequence
            )
        }

        var damage = (state.hero.attack - state.enemy.defense)
            .coerceAtLeast(1)

        when (dice.outcome) {
            DiceOutcome.EXCEPTIONAL_SUCCESS ->
                damage = (damage * 1.5).toInt()

            DiceOutcome.EXTRAORDINARY_SUCCESS ->
                damage *= 2

            else -> Unit
        }

        if (state.enemyDefending) {
            damage = (damage / 2).coerceAtLeast(1)
        }

        val vulnerabilityBonus = state.enemyVulnerable

        if (vulnerabilityBonus) {
            damage = (damage * 1.5).toInt().coerceAtLeast(1)
        }

        val updatedEnemy = state.enemy.copy(
            hp = (state.enemy.hp - damage).coerceAtLeast(0)
        )

        val damageLog = "${state.hero.name} causou $damage de dano!"

        val vulnerabilityLog = if (vulnerabilityBonus) {
            "Você explorou a vulnerabilidade do inimigo! Dano aumentado em 50%!"
        } else {
            ""
        }

        val resultLog = when (dice.outcome) {
            DiceOutcome.EXCEPTIONAL_SUCCESS ->
                "Ataque excepcional! Dano aumentado!"

            DiceOutcome.EXTRAORDINARY_SUCCESS ->
                "ACERTO EXTRAORDINÁRIO! Você encontrou uma abertura e causou dano devastador!"

            else -> ""
        }

        val newLog = state.log + rollLog +
            resultLog + vulnerabilityLog + damageLog

        if (!updatedEnemy.isAlive) {
            val reward = calculateVictoryXp(
                state.hero,
                updatedEnemy,
                state.playerContribution
            )

            return state.copy(
                enemy = updatedEnemy,
                enemyDefending = false,
                enemyVulnerable = false,
                phase = CombatPhase.VICTORY,
                xpGained = reward,
                log = newLog +
                    "${updatedEnemy.name} foi derrotado!" +
                    "Você recebeu $reward XP!"
            )
        }

        return state.copy(
            enemy = updatedEnemy,
            enemyDefending = false,
            enemyVulnerable = false,
            phase = CombatPhase.ENEMY_TURN,
            log = newLog
        )
    }

    fun enemyAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.ENEMY_TURN) return state

        val decision = WorldAI.decideMonsterAction(
            AICombatContext(
                enemyHp = state.enemy.hp,
                enemyMaxHp = state.enemy.maxHp,
                playerHp = state.hero.hp,
                playerMaxHp = state.hero.maxHp,
                enemyMana = state.enemy.mana,
                enemyManaMax = state.enemy.maxMana,
                enemyRank = state.enemy.rank,
                turn = state.turn,
                enemyAttack = state.enemy.attack,
                enemyLevel = state.enemy.level,
                danger = state.enemy.danger,
                isBoss = state.enemy.isBoss
            )
        )

        val actionLog = state.log + decision.explanation

        return when (decision.action) {

            AIAction.ATTACK ->
                performEnemyAttack(
                    state,
                    decision.proposedDamage,
                    actionLog,
                    false
                )

            AIAction.SPECIAL -> {
                if (state.enemy.mana < 20) {
                    performEnemyAttack(
                        state,
                        decision.proposedDamage,
                        actionLog,
                        false
                    )
                } else {
                    performEnemyAttack(
                        state,
                        decision.proposedDamage,
                        actionLog,
                        true
                    )
                }
            }

            AIAction.DEFEND ->
                state.copy(
                    phase = CombatPhase.PLAYER_TURN,
                    turn = state.turn + 1,
                    enemyDefending = true,
                    log = actionLog +
                        "${state.enemy.name} está se defendendo!"
                )

            AIAction.RETREAT ->
                state.copy(
                    phase = CombatPhase.ENEMY_ESCAPED,
                    log = actionLog +
                        "${state.enemy.name} fugiu do combate!"
                )
        }
    }

    private fun performEnemyAttack(
        state: CombatState,
        proposedDamage: Int,
        currentLog: List<String>,
        special: Boolean
    ): CombatState {

        val modifier = (
            (state.enemy.agility - state.hero.agility) / 3
        ).coerceIn(-3, 3)

        val dice = DiceSystem.rollD20(modifier)

        val rollLog =
            "Rolagem do inimigo: ${dice.naturalRoll} + ${dice.modifier} = ${dice.total}. ${dice.description}"

        val updatedEnemy = if (special) {
            state.enemy.copy(
                mana = (state.enemy.mana - 20).coerceAtLeast(0)
            )
        } else {
            state.enemy
        }

        if (
            dice.outcome == DiceOutcome.CATASTROPHIC_FAILURE ||
            dice.outcome == DiceOutcome.FAILURE ||
            dice.outcome == DiceOutcome.WEAK_RESULT
        ) {
            val catastrophic =
                dice.outcome == DiceOutcome.CATASTROPHIC_FAILURE

            val failureMessage = if (catastrophic) {
                "${state.enemy.name} sofreu uma falha crítica e ficou vulnerável!"
            } else {
                "${state.enemy.name} errou o ataque!"
            }

            return state.copy(
                enemy = updatedEnemy,
                enemyVulnerable = state.enemyVulnerable || catastrophic,
                phase = CombatPhase.PLAYER_TURN,
                turn = state.turn + 1,
                log = currentLog + rollLog + failureMessage +
                    "Seu turno começou!"
            )
        }

        val damageAfterDefense =
            (proposedDamage - state.hero.defense).coerceAtLeast(1)

        var adjustedDamage = damageAfterDefense

        when (dice.outcome) {
            DiceOutcome.EXCEPTIONAL_SUCCESS ->
                adjustedDamage = (adjustedDamage * 1.5).toInt()

            DiceOutcome.EXTRAORDINARY_SUCCESS ->
                adjustedDamage *= 2

            else -> Unit
        }


        val vulnerabilityBonus = state.playerVulnerable

        if (vulnerabilityBonus) {
            adjustedDamage =
                (adjustedDamage * 1.5).toInt().coerceAtLeast(1)
        }

        // Aplica a redução da defesa do jogador.
        if (state.playerDefending) {
            adjustedDamage = (
                adjustedDamage *
                (100 - state.defenseReduction) / 100
            ).coerceAtLeast(1)
        }

        val balancedDamage = BalanceEngine.calculateDamage(

            proposedDamage = adjustedDamage,
            playerHp = state.hero.hp,
            playerMaxHp = state.hero.maxHp,
            danger = state.enemy.danger,
            enemyRank = state.enemy.rank,
            isBoss = state.enemy.isBoss
        )

        val damage = balancedDamage.damage

        val updatedHero = state.hero.copy(
            hp = (state.hero.hp - damage).coerceAtLeast(0)
        )

        val vulnerabilityMessage = if (vulnerabilityBonus) {
            "O inimigo explorou sua vulnerabilidade! Dano aumentado em 50%!"
        } else {
            ""
        }

        val attackMessage = if (special) {
            "${state.enemy.name} usou uma habilidade especial e causou $damage de dano!"
        } else {
            "${state.enemy.name} causou $damage de dano!"
        }

        val resultMessage = when (dice.outcome) {
            DiceOutcome.EXCEPTIONAL_SUCCESS ->
                "Ataque excepcional do inimigo! Dano aumentado!"

            DiceOutcome.EXTRAORDINARY_SUCCESS ->
                "ATAQUE EXTRAORDINÁRIO! O inimigo encontrou uma abertura devastadora!"

            else -> ""
        }

        if (!updatedHero.isAlive) {
            return state.copy(
                playerDefending = false,
                defenseReduction = 0,
                hero = updatedHero,
                enemy = updatedEnemy,
                playerVulnerable = false,
                phase = CombatPhase.DEFEAT,
                log = currentLog + rollLog +
                    resultMessage + vulnerabilityMessage +
                    attackMessage + "Você foi derrotado!"
            )
        }

        return state.copy(
            hero = updatedHero,
            enemy = updatedEnemy,
            playerVulnerable = false,
            playerDefending = false,
            defenseReduction = 0,
            phase = CombatPhase.PLAYER_TURN,
            turn = state.turn + 1,
            log = currentLog +
                rollLog +
                resultMessage +
                vulnerabilityMessage +
                attackMessage +
                balancedDamage.description +
                "Seu turno começou!"
        )
    }

    private fun calculateVictoryXp(
        hero: Combatant,
        enemy: Combatant,
        contribution: Float
    ): Int {
        return BalanceEngine.calculateXp(
            BalanceContext(
                playerLevel = hero.level,
                playerRank = hero.rank,
                enemyLevel = enemy.level,
                enemyRank = enemy.rank,
                enemyMaxHp = enemy.maxHp,
                enemyAttack = enemy.attack,
                enemyDefense = enemy.defense,
                enemyBaseXp = enemy.xpReward,
                danger = enemy.danger,
                isBoss = enemy.isBoss,
                playerContribution = contribution
            )
        ).xp
    }
}
