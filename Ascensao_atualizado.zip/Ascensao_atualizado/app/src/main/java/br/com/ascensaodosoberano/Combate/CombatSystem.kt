
package br.com.ascensaodosoberano.combat

enum class CombatPhase {
    PLAYER_TURN,
    ENEMY_TURN,
    VICTORY,
    DEFEAT
}

data class Combatant(
    val name: String,
    val maxHp: Int,
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val mana: Int = 0,
    val maxMana: Int = mana
) {
    val isAlive: Boolean
        get() = hp > 0
}

data class CombatState(
    val hero: Combatant,
    val enemy: Combatant,
    val phase: CombatPhase = CombatPhase.PLAYER_TURN,
    val turn: Int = 1,
    val log: List<String> = emptyList()
)

object CombatSystem {

    fun startCombat(
        hero: Combatant,
        enemy: Combatant
    ): CombatState {
        return CombatState(
            hero = hero,
            enemy = enemy,
            log = listOf("Combate iniciado contra ${enemy.name}!")
        )
    }

    fun playerAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.PLAYER_TURN) return state

        val damage = (state.hero.attack - state.enemy.defense)
            .coerceAtLeast(1)

        val updatedEnemy = state.enemy.copy(
            hp = (state.enemy.hp - damage).coerceAtLeast(0)
        )

        val newLog = state.log + 
            "${state.hero.name} causou $damage de dano!"

        if (!updatedEnemy.isAlive) {
            return state.copy(
                enemy = updatedEnemy,
                phase = CombatPhase.VICTORY,
                log = newLog + "${updatedEnemy.name} foi derrotado!"
            )
        }

        return state.copy(
            enemy = updatedEnemy,
            phase = CombatPhase.ENEMY_TURN,
            log = newLog
        )
    }

    fun enemyAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.ENEMY_TURN) return state

        val damage = (state.enemy.attack - state.hero.defense)
            .coerceAtLeast(1)

        val updatedHero = state.hero.copy(
            hp = (state.hero.hp - damage).coerceAtLeast(0)
        )

        val newLog = state.log +
            "${state.enemy.name} causou $damage de dano!"

        if (!updatedHero.isAlive) {
            return state.copy(
                hero = updatedHero,
                phase = CombatPhase.DEFEAT,
                log = newLog + "Você foi derrotado!"
            )
        }

        return state.copy(
            hero = updatedHero,
            phase = CombatPhase.PLAYER_TURN,
            turn = state.turn + 1,
            log = newLog + "Seu turno começou!"
        )
    }
}
