
package br.com.ascensaodosoberano.combat

import br.com.ascensaodosoberano.world.AIAction
import br.com.ascensaodosoberano.world.AICombatContext
import br.com.ascensaodosoberano.world.BalanceContext
import br.com.ascensaodosoberano.world.BalanceEngine
import br.com.ascensaodosoberano.world.WorldAI

enum class CombatPhase {
    PLAYER_TURN,
    ENEMY_TURN,
    VICTORY,
    DEFEAT,
    ENEMY_ESCAPED
}

data class Combatant(
    val name: String,
    val maxHp: Int,
    val hp: Int,
    val attack: Int,
    val defense: Int,
    val mana: Int = 0,
    val maxMana: Int = mana,
    val rank: String = "E",
    val level: Int = 1,
    val danger: Int = 30,
    val xpReward: Int = 0,
    val isBoss: Boolean = false
) {
    val isAlive: Boolean
        get() = hp > 0
}

data class CombatState(
    val hero: Combatant,
    val enemy: Combatant,
    val phase: CombatPhase = CombatPhase.PLAYER_TURN,
    val turn: Int = 1,
    val log: List<String> = emptyList(),
    val enemyDefending: Boolean = false,
    val playerContribution: Float = 1f,
    val xpGained: Int = 0
)

object CombatSystem {

    fun startCombat(
        hero: Combatant,
        enemy: Combatant
    ): CombatState {
        return CombatState(
            hero = hero,
            enemy = enemy,
            log = listOf("Combate iniciado contra ${enemy.name}!")
        )
    }

    fun playerAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.PLAYER_TURN) return state

        var damage = (state.hero.attack - state.enemy.defense)
            .coerceAtLeast(1)

        if (state.enemyDefending) {
            damage = (damage / 2).coerceAtLeast(1)
        }

        val updatedEnemy = state.enemy.copy(
            hp = (state.enemy.hp - damage).coerceAtLeast(0)
        )

        val newLog = state.log +
            "${state.hero.name} causou $damage de dano!"

        if (!updatedEnemy.isAlive) {
            val reward = calculateVictoryXp(
                state.hero,
                updatedEnemy,
                state.playerContribution
            )

            return state.copy(
                enemy = updatedEnemy,
                enemyDefending = false,
                phase = CombatPhase.VICTORY,
                xpGained = reward,
                log = newLog +
                    "${updatedEnemy.name} foi derrotado!" +
                    "Você recebeu $reward XP!"
            )
        }

        return state.copy(
            enemy = updatedEnemy,
            enemyDefending = false,
            phase = CombatPhase.ENEMY_TURN,
            log = newLog
        )
    }

    fun enemyAttack(state: CombatState): CombatState {
        if (state.phase != CombatPhase.ENEMY_TURN) return state

        val decision = WorldAI.decideMonsterAction(
            AICombatContext(
                enemyHp = state.enemy.hp,
                enemyMaxHp = state.enemy.maxHp,
                playerHp = state.hero.hp,
                playerMaxHp = state.hero.maxHp,
                enemyMana = state.enemy.mana,
                enemyManaMax = state.enemy.maxMana,
                enemyRank = state.enemy.rank,
                turn = state.turn,
                enemyAttack = state.enemy.attack,
                enemyLevel = state.enemy.level,
                danger = state.enemy.danger,
                isBoss = state.enemy.isBoss
            )
        )

        val actionLog = state.log + decision.explanation

        return when (decision.action) {

            AIAction.ATTACK ->
                performEnemyAttack(state, decision.proposedDamage, actionLog, false)

            AIAction.SPECIAL -> {
                if (state.enemy.mana < 20) {
                    performEnemyAttack(state, decision.proposedDamage, actionLog, false)
                } else {
                    performEnemyAttack(state, decision.proposedDamage, actionLog, true)
                }
            }

            AIAction.DEFEND ->
                state.copy(
                    phase = CombatPhase.PLAYER_TURN,
                    turn = state.turn + 1,
                    enemyDefending = true,
                    log = actionLog + "${state.enemy.name} está se defendendo!"
                )

            AIAction.RETREAT ->
                state.copy(
                    phase = CombatPhase.ENEMY_ESCAPED,
                    log = actionLog + "${state.enemy.name} fugiu do combate!"
                )
        }
    }

    private fun performEnemyAttack(
        state: CombatState,
        proposedDamage: Int,
        currentLog: List<String>,
        special: Boolean
    ): CombatState {

        val damageAfterDefense =
            (proposedDamage - state.hero.defense).coerceAtLeast(1)

        val balancedDamage = BalanceEngine.calculateDamage(
            proposedDamage = damageAfterDefense,
            playerHp = state.hero.hp,
            playerMaxHp = state.hero.maxHp,
            danger = state.enemy.danger,
            enemyRank = state.enemy.rank,
            isBoss = state.enemy.isBoss
        )

        val damage = balancedDamage.damage

        val updatedHero = state.hero.copy(
            hp = (state.hero.hp - damage).coerceAtLeast(0)
        )

        val updatedEnemy = if (special) {
            state.enemy.copy(
                mana = (state.enemy.mana - 20).coerceAtLeast(0)
            )
        } else {
            state.enemy
        }

        val attackMessage = if (special) {
            "${state.enemy.name} usou uma habilidade especial e causou $damage de dano!"
        } else {
            "${state.enemy.name} causou $damage de dano!"
        }

        if (!updatedHero.isAlive) {
            return state.copy(
                hero = updatedHero,
                enemy = updatedEnemy,
                phase = CombatPhase.DEFEAT,
                log = currentLog + attackMessage + "Você foi derrotado!"
            )
        }

        return state.copy(
            hero = updatedHero,
            enemy = updatedEnemy,
            phase = CombatPhase.PLAYER_TURN,
            turn = state.turn + 1,
            log = currentLog +
                attackMessage +
                balancedDamage.description +
                "Seu turno começou!"
        )
    }

    private fun calculateVictoryXp(
        hero: Combatant,
        enemy: Combatant,
        contribution: Float
    ): Int {
        return BalanceEngine.calculateXp(
            BalanceContext(
                playerLevel = hero.level,
                playerRank = hero.rank,
                enemyLevel = enemy.level,
                enemyRank = enemy.rank,
                enemyMaxHp = enemy.maxHp,
                enemyAttack = enemy.attack,
                enemyDefense = enemy.defense,
                enemyBaseXp = enemy.xpReward,
                danger = enemy.danger,
                isBoss = enemy.isBoss,
                playerContribution = contribution
            )
        ).xp
    }
}
