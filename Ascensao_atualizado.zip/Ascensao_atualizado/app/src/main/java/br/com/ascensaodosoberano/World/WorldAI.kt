
package br.com.ascensaodosoberano.world

import kotlin.random.Random

enum class AIAction {
    ATTACK,
    DEFEND,
    SPECIAL,
    RETREAT
}

data class AICombatContext(
    val enemyHp: Int,
    val enemyMaxHp: Int,
    val playerHp: Int,
    val playerMaxHp: Int,
    val enemyMana: Int,
    val enemyManaMax: Int,
    val enemyRank: String,
    val turn: Int,
    val enemyAttack: Int = 1,
    val enemyLevel: Int = 1,
    val danger: Int = 30,
    val isBoss: Boolean = false
)

data class AICombatDecision(
    val action: AIAction,
    val explanation: String,
    val proposedDamage: Int = 0
)

object WorldAI {

    fun decideMonsterAction(
        context: AICombatContext
    ): AICombatDecision {

        val enemyHp = context.enemyHp.toFloat() /
            context.enemyMaxHp.coerceAtLeast(1)

        val playerHp = context.playerHp.toFloat() /
            context.playerMaxHp.coerceAtLeast(1)

        val mana = context.enemyMana
        val danger = context.danger.coerceIn(1, 100)
        val roll = Random.nextInt(100)

        val action = when {
            enemyHp <= 0.10f && !context.isBoss && roll < 70 ->
                AIAction.RETREAT

            enemyHp < 0.30f && roll < 45 ->
                AIAction.DEFEND

            mana >= 20 && roll < (25 + danger / 3) ->
                AIAction.SPECIAL

            playerHp < 0.25f && roll < 80 ->
                AIAction.ATTACK

            roll < 25 ->
                AIAction.DEFEND

            else ->
                AIAction.ATTACK
        }

        val damageMultiplier = when (action) {
            AIAction.ATTACK -> Random.nextDouble(0.85, 1.20)
            AIAction.SPECIAL -> Random.nextDouble(1.30, 1.80)
            else -> 0.0
        }

        val proposedDamage = (
            context.enemyAttack * damageMultiplier
        ).toInt().coerceAtLeast(0)

        val explanation = when (action) {
            AIAction.ATTACK ->
                "O inimigo analisou sua situação e decidiu atacar!"

            AIAction.DEFEND ->
                "O inimigo percebeu o perigo e assumiu uma posição defensiva."

            AIAction.SPECIAL ->
                "O inimigo concentrou energia e preparou uma habilidade especial!"

            AIAction.RETREAT ->
                "O inimigo avaliou o risco e decidiu fugir!"
        }

        return AICombatDecision(
            action = action,
            explanation = explanation,
            proposedDamage = proposedDamage
        )
    }

    fun generateWorldReaction(
        regionName: String,
        dangerLevel: Int
    ): String {
        return when {
            dangerLevel >= 90 ->
                "Uma presença aterradora altera a atmosfera de $regionName."

            dangerLevel >= 60 ->
                "Movimentos estranhos são percebidos em $regionName."

            dangerLevel >= 30 ->
                "A região $regionName apresenta sinais de atividade."

            else ->
                "A região $regionName permanece relativamente tranquila."
        }
    }
}
