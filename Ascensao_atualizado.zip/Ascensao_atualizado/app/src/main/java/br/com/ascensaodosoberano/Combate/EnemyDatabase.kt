
package br.com.ascensaodosoberano.combat

data class Enemy(
    val id: String,
    val name: String,
    val rank: String,
    val maxHp: Int,
    val attack: Int,
    val defense: Int,
    val xpReward: Int,
    val imageKey: String,
    val description: String,
    val isBoss: Boolean = false
)

object EnemyDatabase {

    private val enemies = listOf(

        Enemy(
            id = "shadow_wolf",
            name = "Lobo das Sombras",
            rank = "E",
            maxHp = 120,
            attack = 18,
            defense = 5,
            xpReward = 50,
            imageKey = "shadow_wolf",
            description = "Predador que caça nas florestas escuras."
        ),

        Enemy(
            id = "abyss_crawler",
            name = "Rastejante do Abismo",
            rank = "C",
            maxHp = 650,
            attack = 75,
            defense = 30,
            xpReward = 250,
            imageKey = "abyss_crawler",
            description = "Criatura rastejante corrompida por energia abissal."
        ),

        Enemy(
            id = "dimensional_predator",
            name = "Predador das Fendas",
            rank = "SS",
            maxHp = 12000,
            attack = 950,
            defense = 500,
            xpReward = 2500,
            imageKey = "dimensional_predator",
            description = "Caçador dimensional que atravessa as fronteiras da realidade."
        ),

        Enemy(
            id = "nhar_zul_boss",
            name = "Colosso de Nhar-Zul",
            rank = "SSS",
            maxHp = 80000,
            attack = 4500,
            defense = 2200,
            xpReward = 10000,
            imageKey = "nhar_zul_boss",
            description = "Entidade colossal das Terras Mortas.",
            isBoss = true
        )
    )

    fun getAll(): List<Enemy> = enemies

    fun getById(id: String): Enemy? {
        return enemies.find { it.id == id }
    }

    fun getByRank(rank: String): List<Enemy> {
        return enemies.filter {
            it.rank.equals(rank, ignoreCase = true)
        }
    }

    fun getBosses(): List<Enemy> {
        return enemies.filter { it.isBoss }
    }
}
