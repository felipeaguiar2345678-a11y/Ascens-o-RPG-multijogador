package br.com.

    fun explore(region: ExplorationRegion): ExplorationEncounter {
        val event = WorldDirector.generateEvent(
            WorldContext(
                regionName = region.name,
                regionRank = region.rank.name,
                dangerLevel = region.encounterChance
            )
        )

        val isEncounter = event.type.name == "ENCOUNTER" ||
                event.type.name == "BOSS"

        return ExplorationEncounter(
            region = region,
            enemyId = null,
            isBoss = event.type.name == "BOSS",
            message = event.description,
            worldEvent = event
        )
    }
}
